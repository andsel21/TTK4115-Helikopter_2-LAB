% FOR HELICOPTER NR 1-2
% This file contains the initialization for the helicopter assignment in
% the course TTK4115. Run this file before you execute QuaRC_ -> Build 
% to build the file heli_q8.mdl.

% Oppdatert h�sten 2006 av Jostein Bakkeheim
% Oppdatert h�sten 2008 av Arnfinn Aas Eielsen
% Oppdatert h�sten 2009 av Jonathan Ronen
% Updated fall 2010, Dominik Breu
% Updated fall 2013, Mark Haring
% Updated spring 2015, Mark Haring

close all
clear
clc
%  stop(timerfindall)
%  delete(timerfindall)

%%%%%%%%%%% Calibration of the encoder and the hardware for the specific
%%%%%%%%%%% helicopter
Joystick_gain_x = 1;
Joystick_gain_y = -1;


%%%%%%%%%%% Physical constants
g = 9.81; % gravitational constant [m/s^2]
l_c = 0.40; % distance elevation axis to counterweight [m]
l_h = 0.66; % distance elevation axis to helicopter head [m]
l_p = 0.175; % distance pitch axis to motor [m]
m_c = 1.92; % Counterweight mass [kg]
m_p = 0.65; % Motor mass [kg]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Change at startup
PORT = 3;

%% Variables
% constant_elevation = 0.0;%4.602;
v_s0 = 6.17;

Kf = (g*(-m_c*l_c+2*m_p*l_h))/(l_h*v_s0);

J_p = 2*m_p*l_p^2;
J_e = m_c*l_c^2 + 2*m_p*l_h^2;
J_lamda = m_c*l_c^2 + 2*m_p*(l_h^2+l_p^2);

L1 = l_p*Kf;
L3 = l_h * Kf;
L4 = g * Kf * (l_c * m_c - 2 * l_h * m_p);

% La til
K1 = L1/J_p;
K2 = L3/J_e;
K3 = L4/J_lamda*v_s0;

%% State Space
A = [0 1 0  0 0; 
     0 0 0  0 0;
     0 0 0  0 0;
    -1 0 0  0 0;
     0 0 -1 0 0]; 
B = [ 0 0;
      0 K1;
     K2 0;
      0 0;
      0 0];

G = [0 0
     0 0
     0 0 
     1 0
     0 1];
 
%% LQR Matrix
 Q_LQR = [100 0 0 0 0; 
          0 40 0 0 0;
          0 0 5 0 0;
          0 0 0 1 0;
          0 0 0 0 10];
          
R_LQR = [0.1 0;
         0 0.7];

%% Calc K
K = lqr(A, B, Q_LQR, R_LQR, G);

F = [K(1,1) K(1,3);
     K(2,1) K(2,3)];

%% 2.4 Part IV - Kalman Filter
% Sampling time
T_s = 0.002; 


%% 2.4.1 Discretization (6-state model: x = [p, p_dot, e, e_dot, lambda, lambda_dot]')
A_c = [0  1  0  0  0  0;
       0  0  0  0  0  0;
       0  0  0  1  0  0;
       0  0  0  0  0  0;
       0  0  0  0  0  1;
       K3 0  0  0  0  0];

B_c = [0   0;
       0  K1;
       0   0;
       K2  0;
       0   0;
       0   0];

% Output matrix C_c:
% Option A: Measuring only the 5 IMU states [p, p_dot, e, e_dot, lambda, lambda_dot]'
C_c = [1 0 0 0 0 0;
       0 1 0 0 0 0;
       0 0 1 0 0 0;
       0 0 0 1 0 0;
       0 0 0 0 0 1];

% Option B: Uncomment below if measuring all 6 states (IMU + travel encoder)
%C_c = eye(6);

D_c = zeros(size(C_c, 1), size(B_c, 2));

% Discretize using Zero-Order Hold (c2d)
sys_c = ss(A_c, B_c, C_c, D_c);
sys_d = c2d(sys_c, T_s, 'zoh');

A_d = sys_d.A;
B_d = sys_d.B;
C_d = sys_d.C;
D_d = sys_d.D;

x_bar_0 = zeros(6,1);
P_bar_0 = eye(6);
%% Noise Covariance Matrices (Q_d and R_d)

n_states = size(A_d, 1);       % 6 states
n_meas   = size(C_d, 1);       % 5 (or 6) measurements

% Scalar tuning variables
q = 0.001;                % Process noise tuning parameter
%r = 1e-2;                      % Measurement noise tuning parameter

% Direct discrete covariance matrices
Q_d = q * eye(n_states);
%%R_d = r * eye(n_meas);

data = load("R_d_FlyingTimeseriesV2.mat");
S = data.ans;
t=S(1,:)';
Y=S(2:6,:)';
R_d = cov(Y);


