% FOR HELICOPTER NR 1-2
% This file contains the initialization for the helicopter assignment in
% the course TTK4115. Run this file before you execute QuaRC_ -> Build 
% to build the file heli_q8.mdl.

% Oppdatert h�sten 2006 av Jostein Bakkeheim
% Oppdatert h�sten 2008 av Arnfinn Aas Eielsen
% Oppdatert h�sten 2009 av Jonathan Ronen
% Updated fall 2010, Dominik Breu
% Updated fall 2013, Mark Haring
% Updated spring 2015, Mark Haring

close all
clear
clc

%%%%%%%%%%% Calibration of the encoder and the hardware for the specific
%%%%%%%%%%% helicopter
Joystick_gain_x = 1;
Joystick_gain_y = -1;


%%%%%%%%%%% Physical constants
g = 9.81; % gravitational constant [m/s^2]
l_c = 0.40; % distance elevation axis to counterweight [m]
l_h = 0.66; % distance elevation axis to helicopter head [m]
l_p = 0.175; % distance pitch axis to motor [m]
m_c = 1.92; % Counterweight mass [kg]
m_p = 0.65; % Motor mass [kg]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
v_s0 = 6.17;

Kf = (g*(-m_c*l_c+2*m_p*l_h))/(l_h*v_s0);

J_p = 2*m_p*l_p^2;
L1 = l_p*Kf;
K1 = L1/J_p;

%% Pole placement
% Desired pole
lambda1 = -2 + 3i; 
lambda2 = -2 - 3i;
% Calculate gains
K_pp = (lambda1 * lambda2)/K1;
K_pd = -(lambda1 + lambda2)/K1;

