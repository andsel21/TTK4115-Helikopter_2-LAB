
g = 9.81; % gravitational constant [m/s^2]
l_c = 0.40; % distance elevation axis to counterweight [m]
l_h = 0.66; % distance elevation axis to helicopter head [m]
l_p = 0.175; % distance pitch axis to motor [m]
m_c = 1.92; % Counterweight mass [kg]
m_p = 0.65; % Motor mass [kg]

% System parameter

Lp = 0.175;
Kf = 0.2168;
J_p = 2*m_p*l_p^2;
L1 = l_p*Kf;
K1 = L1/J_p;

% Desired poles
lambda1 = -2 ; 
lambda2 = -2 ;

% Calculate gains
Kpd = -(lambda1 + lambda2)/K1
Kpp = (lambda1 * lambda2)/K1

fprintf('Kpd = %.4f\n', Kpd);
fprintf('Kpp = %.4f\n', Kpp);