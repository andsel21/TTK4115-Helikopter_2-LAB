% FOR HELICOPTER NR 1-2
% This file contains the initialization for the helicopter assignment in
% the course TTK4115. Run this file before you execute QuaRC_ -> Build 
% to build the file heli_q8.mdl.

% Oppdatert h�sten 2006 av Jostein Bakkeheim
% Oppdatert h�sten 2008 av Arnfinn Aas Eielsen
% Oppdatert h�sten 2009 av Jonathan Ronen
% Updated fall 2010, Dominik Breu
% Updated fall 2013, Mark Haring
% Updated spring 2015, Mark Haring

close all
clear
clc

%%%%%%%%%%% Calibration of the encoder and the hardware for the specific
%%%%%%%%%%% helicopter
Joystick_gain_x = 1;
Joystick_gain_y = -1;


%%%%%%%%%%% Physical constants
g = 9.81; % gravitational constant [m/s^2]
l_c = 0.40; % distance elevation axis to counterweight [m]
l_h = 0.66; % distance elevation axis to helicopter head [m]
l_p = 0.175; % distance pitch axis to motor [m]
m_c = 1.92; % Counterweight mass [kg]
m_p = 0.65; % Motor mass [kg]

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Our Code start
% constant_elevation = 0.0;%4.602;
v_s0 = 6.17;

Kf = (g*(-m_c*l_c+2*m_p*l_h))/(l_h*v_s0);

L1 = l_p*Kf;
L3 = l_h * Kf;

J_p = 2*m_p*l_p^2;
J_e = m_c*l_c^2 + 2*m_p*l_h^2;

K1 = L1/J_p;
K2 = L3/J_e;


%% Task 1 LQR
A = [0 1 0; 
     0 0 0;
     0 0 0]; 
B = [0 0;
     0 K1;
     K2 0];
 
%% TEST: Step Pitch
Q_LQR = [1 0 0; 
         0 1 0;
         0 0 1];
R_LQR = [1 0;
         0 1];
%% Calc K
K = lqr(A, B, Q_LQR, R_LQR);

F = [K(1,1) K(1,3);
     K(2,1) K(2,3)];

 