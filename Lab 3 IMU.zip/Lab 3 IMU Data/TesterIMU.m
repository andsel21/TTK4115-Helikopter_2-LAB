
%% IMU01 
% Occilering
% Krasjet ikke
p = [-2 -4 -4 -6 -7];

%% IMU02 
% Cooked, Ustabil som faen
p = [2 4 4 6 7];

%% IMU03
% Skal ikke være ustabil, men gikk ikke av bakken
C_IMU = [0 0 0 0 0;
         0 0 0 0 0;
         0 0 1 0 0;
         0 0 0 0 0;
         0 0 0 0 1];
p = [-2 -4 -4 -6 -7];

%% IMU04
% ingen reaksjon kom såvit av bakken før står stille
C_IMU = [0 0 0 0 0;
         0 0 0 0 0;
         0 0 1 0 0;
         0 0 0 0 0;
         0 0 0 0 1];
B_IMU = [0 0
         0 K1
         0 0
         K2 0
         0 0];

%p = [-2 -4 -4 -6 -7]; %% Mulig skal være + for negative poler 
p = [-2 -4 -400 -6 -700];

%% IMU05 STore verdi og hele c
p = [-2 -4 -400 -6 -700];


%% IMU06 Komplekse poler
% Ikke stabil
p = [-2+2*1i -2-2*1i -4 -6 -7];

%% IMU07 Ta vekk bare p_dot
% Ikke occilerende, treg, funket egentlig ikke som "stabilt system"
% Krasjet
C_IMU = [1 0 0 0 0;
         0 0 0 0 0;
         0 0 1 0 0;
         0 0 0 1 0;
         0 0 0 0 1];
p = [-2 -4 -4 -6 -7];


%% IMU08 Ta vekk bare p_dot med å sette pol lav. Ustabilt occilerte mer og mer
p = [-2 -0.01 -4 -6 -7];