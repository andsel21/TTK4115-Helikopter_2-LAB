%% Test 1: q = 1

%% Test 2: q = 100
% Så ikke forskjell plot mot 1 igjen
%% Test 3: q = 100000000;    
% Bruker bare LQR Nå som forventet
%% Test 4: q = 0.01
% Litt mer ustabil (bare tor tenkte det) 

%% Test 5: q = 0.0001
% Mindre støy, avhengig av estimat/ blir Faen dårlig siden bruker mer
% estimat enn nødvendig
%% Test 6: q= 0

%% Test 7: Slå av å på forsjellige 
% Fungerer, H
% Stopper, holder verdi og så avviker
%% Test 8: Q høyerer: Q = 100
