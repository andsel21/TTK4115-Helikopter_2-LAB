/*
 * heli_q8.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "heli_q8".
 *
 * Model version              : 11.36
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Nov  4 18:43:26 2026
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "heli_q8.h"
#include "heli_q8_private.h"
#include "heli_q8_dt.h"

t_stream heli_q8_rtZt_stream = NULL;

/* Block signals (default storage) */
B_heli_q8_T heli_q8_B;

/* Continuous states */
X_heli_q8_T heli_q8_X;

/* Block states (default storage) */
DW_heli_q8_T heli_q8_DW;

/* Real-time model */
static RT_MODEL_heli_q8_T heli_q8_M_;
RT_MODEL_heli_q8_T *const heli_q8_M = &heli_q8_M_;
static void rate_monotonic_scheduler(void);

/*
 * Writes out MAT-file header.  Returns success or failure.
 * Returns:
 *      0 - success
 *      1 - failure
 */
int_T rt_WriteMat4FileHeader(FILE *fp, int32_T m, int32_T n, const char *name)
{
  typedef enum { ELITTLE_ENDIAN, EBIG_ENDIAN } ByteOrder;

  int16_T one = 1;
  ByteOrder byteOrder = (*((int8_T *)&one)==1) ? ELITTLE_ENDIAN : EBIG_ENDIAN;
  int32_T type = (byteOrder == ELITTLE_ENDIAN) ? 0: 1000;
  int32_T imagf = 0;
  int32_T name_len = (int32_T)strlen(name) + 1;
  if ((fwrite(&type, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&m, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&n, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&imagf, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&name_len, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(name, sizeof(char), name_len, fp) == 0)) {
    return(1);
  } else {
    return(0);
  }
}                                      /* end rt_WriteMat4FileHeader */

time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
{
  rtmSampleHitPtr[1] = rtmStepTask(heli_q8_M, 1);
  rtmSampleHitPtr[2] = rtmStepTask(heli_q8_M, 2);
  UNUSED_PARAMETER(rtmNumSampTimes);
  UNUSED_PARAMETER(rtmTimingData);
  UNUSED_PARAMETER(rtmPerTaskSampleHits);
  return(-1);
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 1 shares data with slower tid rate: 2 */
  if (heli_q8_M->Timing.TaskCounters.TID[1] == 0) {
    heli_q8_M->Timing.RateInteraction.TID1_2 =
      (heli_q8_M->Timing.TaskCounters.TID[2] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    heli_q8_M->Timing.perTaskSampleHits[5] =
      heli_q8_M->Timing.RateInteraction.TID1_2;
  }

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (heli_q8_M->Timing.TaskCounters.TID[2])++;
  if ((heli_q8_M->Timing.TaskCounters.TID[2]) > 4) {/* Sample time: [0.01s, 0.0s] */
    heli_q8_M->Timing.TaskCounters.TID[2] = 0;
  }
}

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 5;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  heli_q8_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T u0_0;
  int32_T u1_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = atan2(u0_0, u1_0);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

/* Model output function for TID0 */
void heli_q8_output0(void)             /* Sample time: [0.0s, 0.0s] */
{
  /* local block i/o variables */
  t_stream_ptr rtb_StreamCall2_o1;
  real_T rtb_HILReadEncoderTimebase_o1;
  real_T rtb_HILReadEncoderTimebase_o2;
  real_T rtb_TmpSignalConversionAtToFile[20];
  real_T rtb_TmpSignalConversionAtToFi_n[29];
  real_T rtb_DeadZoney;
  int32_T rtb_StreamFormattedRead1_o8;
  int32_T rtb_StreamFormattedRead_o2;
  int32_T rtb_StreamCall2_o3;
  static const int8_T b_I[36] = { 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1 };

  real_T I_LC[36];
  real_T I_LC_0[36];
  real_T I_LC_1[36];
  real_T X_0[36];
  real_T A_tmp[30];
  real_T X[30];
  real_T A[25];
  real_T tmp[9];
  real_T tmp_2[6];
  real_T tmp_3[5];
  real_T tmp_4[5];
  real_T tmp_5[5];
  real_T rtb_euler_rates[3];
  real_T tmp_0[2];
  real_T tmp_1[2];
  real_T rtb_euler_rates_tmp;
  real_T rtb_euler_rates_tmp_0;
  real_T rtb_euler_rates_tmp_1;
  real_T smax;
  int32_T c_ix;
  int32_T d_j;
  int32_T i;
  int32_T ijA;
  int32_T ix;
  int32_T iy;
  int32_T jBcol;
  int32_T kBcol;
  int8_T ipiv[5];
  int8_T ipiv_0;
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    /* set solver stop time */
    if (!(heli_q8_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&heli_q8_M->solverInfo,
                            ((heli_q8_M->Timing.clockTickH0 + 1) *
        heli_q8_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&heli_q8_M->solverInfo,
                            ((heli_q8_M->Timing.clockTick0 + 1) *
        heli_q8_M->Timing.stepSize0 + heli_q8_M->Timing.clockTickH0 *
        heli_q8_M->Timing.stepSize0 * 4294967296.0));
    }

    {                                  /* Sample time: [0.0s, 0.0s] */
      rate_monotonic_scheduler();
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(heli_q8_M)) {
    heli_q8_M->Timing.t[0] = rtsiGetT(&heli_q8_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(heli_q8_DW.Skiptonextline_SubsysRanBC);
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    /* S-Function (hil_read_encoder_timebase_block): '<S3>/HIL Read Encoder Timebase' */

    /* S-Function Block: heli_q8/Heli 3D/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
    {
      t_error result;
      result = hil_task_read_encoder(heli_q8_DW.HILReadEncoderTimebase_Task, 1,
        &heli_q8_DW.HILReadEncoderTimebase_Buffer[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
      } else {
        rtb_HILReadEncoderTimebase_o1 =
          heli_q8_DW.HILReadEncoderTimebase_Buffer[0];
        rtb_HILReadEncoderTimebase_o2 =
          heli_q8_DW.HILReadEncoderTimebase_Buffer[1];
        rtb_DeadZoney = heli_q8_DW.HILReadEncoderTimebase_Buffer[2];
      }
    }

    for (i = 0; i < 6; i++) {
      /* UnitDelay: '<S2>/Unit Delay' */
      heli_q8_B.x_k[i] = heli_q8_DW.UnitDelay_DSTATE[i];
    }

    /* UnitDelay: '<S2>/Unit Delay1' */
    memcpy(&heli_q8_B.P_k[0], &heli_q8_DW.UnitDelay1_DSTATE[0], 36U * sizeof
           (real_T));

    /* S-Function (stream_call_block): '<S11>/Stream Call2' incorporates:
     *  Constant: '<S11>/Constant4'
     *  S-Function (string_constant_block): '<S11>/String Constant1'
     */

    /* S-Function Block: heli_q8/IMU Block/IMU_BT/Stream Call2 (stream_call_block) */
    {
      t_error result = 0;
      t_boolean close_flag = (heli_q8_P.Constant4_Value != 0);
      rtb_StreamCall2_o1 = NULL;
      switch (heli_q8_DW.StreamCall2_State) {
       case STREAM_CALL_STATE_NOT_CONNECTED:
        {
          if (!close_flag) {
            /* Make sure URI is null-terminated */
            if (string_length((char *) heli_q8_P.StringConstant1_Value, 255) ==
                255) {
              rtmSetErrorStatus(heli_q8_M,
                                "URI passed to Stream Call block is not null-terminated!");
              result = -QERR_STRING_NOT_TERMINATED;
            } else {
              result = stream_connect((char *) heli_q8_P.StringConstant1_Value,
                heli_q8_P.StreamCall2_NonBlocking != 0,
                heli_q8_P.StreamCall2_SendBufferSize,
                heli_q8_P.StreamCall2_ReceiveBufferSize,
                &heli_q8_DW.StreamCall2_Stream);
              if (result == 0) {
                heli_q8_DW.StreamCall2_State = STREAM_CALL_STATE_CONNECTED;
                stream_set_byte_order(heli_q8_DW.StreamCall2_Stream,
                                      (t_stream_byte_order)
                                      heli_q8_P.StreamCall2_Endian);
                rtb_StreamCall2_o1 = &heli_q8_DW.StreamCall2_Stream;
              } else if (result == -QERR_WOULD_BLOCK) {
                heli_q8_DW.StreamCall2_State = STREAM_CALL_STATE_CONNECTING;
                result = 0;
              }
            }
          }
          break;
        }

       case STREAM_CALL_STATE_CONNECTING:
        {
          if (!close_flag) {
            const t_timeout timeout = { 0, 0, false };/* zero seconds */

            result = stream_poll(heli_q8_DW.StreamCall2_Stream, &timeout,
                                 STREAM_POLL_CONNECT);
            if (result > 0) {
              heli_q8_DW.StreamCall2_State = STREAM_CALL_STATE_CONNECTED;
              stream_set_byte_order(heli_q8_DW.StreamCall2_Stream,
                                    (t_stream_byte_order)
                                    heli_q8_P.StreamCall2_Endian);
              rtb_StreamCall2_o1 = &heli_q8_DW.StreamCall2_Stream;
              result = 0;
              break;
            } else if (result == 0) {
              break;
            }
          }

          /* Fall through deliberately */
        }

       case STREAM_CALL_STATE_CONNECTED:
        {
          rtb_StreamCall2_o1 = &heli_q8_DW.StreamCall2_Stream;
          if (!close_flag) {
            break;
          }

          /* Fall through deliberately */
        }

       default:
        {
          t_error close_result = stream_close(heli_q8_DW.StreamCall2_Stream);
          if (close_result == 0) {
            heli_q8_DW.StreamCall2_State = STREAM_CALL_STATE_NOT_CONNECTED;
            heli_q8_DW.StreamCall2_Stream = NULL;
            rtb_StreamCall2_o1 = NULL;
          } else if (result == 0) {
            result = close_result;
          }
          break;
        }
      }

      heli_q8_B.StreamCall2_o2 = heli_q8_DW.StreamCall2_State;
      rtb_StreamCall2_o3 = (int32_T) result;
    }

    /* S-Function (stream_formatted_read_block): '<S11>/Stream Formatted Read1' */
    {
      t_error result;
      heli_q8_B.StreamFormattedRead1_o11 = false;
      if (rtb_StreamCall2_o1 != NULL) {
        result = stream_scan_utf8_char_array(*rtb_StreamCall2_o1,
          heli_q8_P.StreamFormattedRead1_MaxUnits, &rtb_StreamFormattedRead1_o8,
          " :%f,%f,%f,%f,%f,%f\r"
          , &heli_q8_B.StreamFormattedRead1_o2
          , &heli_q8_B.StreamFormattedRead1_o3
          , &heli_q8_B.StreamFormattedRead1_o4
          , &heli_q8_B.StreamFormattedRead1_o5
          , &heli_q8_B.StreamFormattedRead1_o6
          , &heli_q8_B.StreamFormattedRead1_o7
          );
        heli_q8_B.StreamFormattedRead1_o11 = (result == 0);
        if (result > 0) {
          result = 0;
        }
      } else {
        rtb_StreamFormattedRead1_o8 = 0;
        result = 0;
        heli_q8_B.StreamFormattedRead1_o2 = 0;
        heli_q8_B.StreamFormattedRead1_o3 = 0;
        heli_q8_B.StreamFormattedRead1_o4 = 0;
        heli_q8_B.StreamFormattedRead1_o5 = 0;
        heli_q8_B.StreamFormattedRead1_o6 = 0;
        heli_q8_B.StreamFormattedRead1_o7 = 0;
      }

      heli_q8_B.StreamFormattedRead1_o10 = (result == -QERR_MISMATCHED_CHARACTER);
    }

    /* DataTypeConversion: '<S11>/Data Type Conversion1' */
    heli_q8_B.DataTypeConversion1[0] = heli_q8_B.StreamFormattedRead1_o2;
    heli_q8_B.DataTypeConversion1[1] = heli_q8_B.StreamFormattedRead1_o3;
    heli_q8_B.DataTypeConversion1[2] = heli_q8_B.StreamFormattedRead1_o4;
    for (d_j = 0; d_j < 3; d_j++) {
      /* Gain: '<S11>/Gain2' */
      heli_q8_B.Gain2[d_j] = 0.0;
      heli_q8_B.Gain2[d_j] += heli_q8_P.Gain2_Gain[d_j] *
        heli_q8_B.DataTypeConversion1[0];
      heli_q8_B.Gain2[d_j] += heli_q8_P.Gain2_Gain[d_j + 3] *
        heli_q8_B.DataTypeConversion1[1];
      heli_q8_B.Gain2[d_j] += heli_q8_P.Gain2_Gain[d_j + 6] *
        heli_q8_B.DataTypeConversion1[2];
    }

    /* MATLAB Function: '<S4>/MATLAB Function' */
    /* MATLAB Function 'IMU Block/MATLAB Function': '<S12>:1' */
    /* '<S12>:1:2' */
    /* '<S12>:1:3' */
    /* '<S12>:1:4' */
    /* '<S12>:1:6' */
    /* '<S12>:1:7' */
    /* '<S12>:1:8' */
    heli_q8_B.pe[0] = rt_atan2d_snf(-heli_q8_B.Gain2[1], -heli_q8_B.Gain2[2]);
    heli_q8_B.pe[1] = rt_atan2d_snf(heli_q8_B.Gain2[0], sqrt(-heli_q8_B.Gain2[1]
      * -heli_q8_B.Gain2[1] + -heli_q8_B.Gain2[2] * -heli_q8_B.Gain2[2]));

    /* DataTypeConversion: '<S11>/Data Type Conversion2' */
    heli_q8_B.DataTypeConversion2[0] = heli_q8_B.StreamFormattedRead1_o5;
    heli_q8_B.DataTypeConversion2[1] = heli_q8_B.StreamFormattedRead1_o6;
    heli_q8_B.DataTypeConversion2[2] = heli_q8_B.StreamFormattedRead1_o7;
    for (d_j = 0; d_j < 3; d_j++) {
      /* Gain: '<S11>/Gain1' */
      heli_q8_B.Gain1[d_j] = 0.0;
      heli_q8_B.Gain1[d_j] += heli_q8_P.Gain1_Gain[d_j] *
        heli_q8_B.DataTypeConversion2[0];
      heli_q8_B.Gain1[d_j] += heli_q8_P.Gain1_Gain[d_j + 3] *
        heli_q8_B.DataTypeConversion2[1];
      heli_q8_B.Gain1[d_j] += heli_q8_P.Gain1_Gain[d_j + 6] *
        heli_q8_B.DataTypeConversion2[2];
    }

    /* MATLAB Function: '<S4>/Gyro vector to [pitch rate, elevation rate, travle rate]' */
    /* MATLAB Function 'IMU Block/Gyro vector to [pitch rate, elevation rate, travle rate]': '<S10>:1' */
    /* '<S10>:1:3' */
    /* '<S10>:1:4' */
    /* '<S10>:1:6' */
    /* '<S10>:1:9' */
    smax = tan(heli_q8_B.pe[1]);
    rtb_euler_rates_tmp = sin(heli_q8_B.pe[0]);
    rtb_euler_rates_tmp_0 = cos(heli_q8_B.pe[0]);
    rtb_euler_rates_tmp_1 = cos(heli_q8_B.pe[1]);
    tmp[0] = 1.0;
    tmp[3] = rtb_euler_rates_tmp * smax;
    tmp[6] = rtb_euler_rates_tmp_0 * smax;
    tmp[1] = 0.0;
    tmp[4] = rtb_euler_rates_tmp_0;
    tmp[7] = -rtb_euler_rates_tmp;
    tmp[2] = 0.0;
    tmp[5] = rtb_euler_rates_tmp / rtb_euler_rates_tmp_1;
    tmp[8] = rtb_euler_rates_tmp_0 / rtb_euler_rates_tmp_1;
    for (d_j = 0; d_j < 3; d_j++) {
      rtb_euler_rates[d_j] = tmp[d_j + 6] * heli_q8_B.Gain1[2] + (tmp[d_j + 3] *
        heli_q8_B.Gain1[1] + tmp[d_j] * heli_q8_B.Gain1[0]);
    }

    /* End of MATLAB Function: '<S4>/Gyro vector to [pitch rate, elevation rate, travle rate]' */

    /* Sum: '<S4>/Sum7' incorporates:
     *  Constant: '<S4>/Constant4'
     */
    heli_q8_B.Sum7 = rtb_euler_rates[0] + heli_q8_P.Constant4_Value_p;

    /* Sum: '<S4>/Sum5' incorporates:
     *  Constant: '<S4>/Constant1'
     */
    heli_q8_B.Sum5 = rtb_euler_rates[1] + heli_q8_P.Constant1_Value;

    /* Sum: '<S4>/Sum2' incorporates:
     *  Constant: '<S4>/Constant'
     */
    heli_q8_B.Sum2 = rtb_euler_rates[2] + heli_q8_P.Constant_Value_c;

    /* UnitDelay: '<S13>/Unit Delay' */
    heli_q8_B.UnitDelay = heli_q8_DW.UnitDelay_DSTATE_i;

    /* RelationalOperator: '<S13>/Relational Operator' */
    heli_q8_B.RelationalOperator = (heli_q8_B.StreamFormattedRead1_o2 ==
      heli_q8_B.UnitDelay);

    /* UnitDelay: '<S14>/Unit Delay' */
    heli_q8_B.UnitDelay_d = heli_q8_DW.UnitDelay_DSTATE_o;

    /* RelationalOperator: '<S14>/Relational Operator' */
    heli_q8_B.RelationalOperator_k = (heli_q8_B.StreamFormattedRead1_o3 ==
      heli_q8_B.UnitDelay_d);

    /* UnitDelay: '<S15>/Unit Delay' */
    heli_q8_B.UnitDelay_f = heli_q8_DW.UnitDelay_DSTATE_od;

    /* RelationalOperator: '<S15>/Relational Operator' */
    heli_q8_B.RelationalOperator_f = (heli_q8_B.StreamFormattedRead1_o4 ==
      heli_q8_B.UnitDelay_f);

    /* UnitDelay: '<S16>/Unit Delay' */
    heli_q8_B.UnitDelay_m = heli_q8_DW.UnitDelay_DSTATE_l;

    /* RelationalOperator: '<S16>/Relational Operator' */
    heli_q8_B.RelationalOperator_o = (heli_q8_B.StreamFormattedRead1_o5 ==
      heli_q8_B.UnitDelay_m);

    /* UnitDelay: '<S17>/Unit Delay' */
    heli_q8_B.UnitDelay_dq = heli_q8_DW.UnitDelay_DSTATE_e;

    /* RelationalOperator: '<S17>/Relational Operator' */
    heli_q8_B.RelationalOperator_l = (heli_q8_B.StreamFormattedRead1_o6 ==
      heli_q8_B.UnitDelay_dq);

    /* UnitDelay: '<S18>/Unit Delay' */
    heli_q8_B.UnitDelay_h = heli_q8_DW.UnitDelay_DSTATE_ei;

    /* RelationalOperator: '<S18>/Relational Operator' */
    heli_q8_B.RelationalOperator_c = (heli_q8_B.StreamFormattedRead1_o7 ==
      heli_q8_B.UnitDelay_h);

    /* ManualSwitch: '<Root>/Manual Switch' */
    if (heli_q8_P.ManualSwitch_CurrentSetting == 1) {
      /* ManualSwitch: '<Root>/Manual Switch' incorporates:
       *  Constant: '<Root>/Constant'
       */
      heli_q8_B.ManualSwitch = heli_q8_P.Constant_Value;
    } else {
      /* ManualSwitch: '<Root>/Manual Switch' incorporates:
       *  Logic: '<S11>/Logical Operator'
       *  Logic: '<S11>/Logical Operator1'
       */
      heli_q8_B.ManualSwitch = ((!heli_q8_B.RelationalOperator) ||
        (!heli_q8_B.RelationalOperator_k) || (!heli_q8_B.RelationalOperator_f) ||
        (!heli_q8_B.RelationalOperator_o) || (!heli_q8_B.RelationalOperator_l) ||
        (!heli_q8_B.RelationalOperator_c));
    }

    /* End of ManualSwitch: '<Root>/Manual Switch' */

    /* MATLAB Function: '<S2>/Correction' incorporates:
     *  UnitDelay: '<S2>/Unit Delay1'
     */
    /* MATLAB Function 'ESTIMATOR/Correction': '<S8>:1' */
    /* '<S8>:1:13' */
    if (heli_q8_B.ManualSwitch != 0.0) {
      /* '<S8>:1:6' */
      /* '<S8>:1:7' */
      for (d_j = 0; d_j < 5; d_j++) {
        for (iy = 0; iy < 6; iy++) {
          i = 5 * iy + d_j;
          A_tmp[iy + 6 * d_j] = heli_q8_P.C_d[i];
          X[i] = 0.0;
          for (jBcol = 0; jBcol < 6; jBcol++) {
            X[i] += heli_q8_P.C_d[5 * jBcol + d_j] * heli_q8_B.P_k[6 * iy +
              jBcol];
          }
        }
      }

      for (d_j = 0; d_j < 5; d_j++) {
        for (iy = 0; iy < 5; iy++) {
          rtb_euler_rates_tmp = 0.0;
          for (jBcol = 0; jBcol < 6; jBcol++) {
            rtb_euler_rates_tmp += X[5 * jBcol + d_j] * A_tmp[6 * iy + jBcol];
          }

          i = 5 * iy + d_j;
          A[i] = heli_q8_P.R_d[i] + rtb_euler_rates_tmp;
        }

        ipiv[d_j] = (int8_T)(d_j + 1);
      }

      for (d_j = 0; d_j < 4; d_j++) {
        jBcol = d_j * 6;
        iy = 0;
        ix = jBcol;
        smax = fabs(A[jBcol]);
        for (kBcol = 2; kBcol <= 5 - d_j; kBcol++) {
          ix++;
          rtb_euler_rates_tmp = fabs(A[ix]);
          if (rtb_euler_rates_tmp > smax) {
            iy = kBcol - 1;
            smax = rtb_euler_rates_tmp;
          }
        }

        if (A[jBcol + iy] != 0.0) {
          if (iy != 0) {
            iy += d_j;
            ipiv[d_j] = (int8_T)(iy + 1);
            ix = d_j;
            for (kBcol = 0; kBcol < 5; kBcol++) {
              smax = A[ix];
              A[ix] = A[iy];
              A[iy] = smax;
              ix += 5;
              iy += 5;
            }
          }

          iy = (jBcol - d_j) + 5;
          for (ix = jBcol + 1; ix < iy; ix++) {
            A[ix] /= A[jBcol];
          }
        }

        iy = jBcol;
        ix = jBcol + 5;
        for (kBcol = 0; kBcol <= 3 - d_j; kBcol++) {
          if (A[ix] != 0.0) {
            smax = -A[ix];
            c_ix = jBcol + 1;
            i = (iy - d_j) + 10;
            for (ijA = iy + 6; ijA < i; ijA++) {
              A[ijA] += A[c_ix] * smax;
              c_ix++;
            }
          }

          ix += 5;
          iy += 5;
        }
      }

      for (d_j = 0; d_j < 5; d_j++) {
        for (iy = 0; iy < 6; iy++) {
          i = iy + 6 * d_j;
          X[i] = 0.0;
          for (jBcol = 0; jBcol < 6; jBcol++) {
            X[i] += heli_q8_B.P_k[6 * jBcol + iy] * A_tmp[6 * d_j + jBcol];
          }
        }
      }

      for (d_j = 0; d_j < 5; d_j++) {
        jBcol = 6 * d_j;
        iy = 5 * d_j;
        for (ix = 0; ix < d_j; ix++) {
          kBcol = 6 * ix;
          if (A[ix + iy] != 0.0) {
            for (c_ix = 0; c_ix < 6; c_ix++) {
              i = c_ix + jBcol;
              X[i] -= A[ix + iy] * X[c_ix + kBcol];
            }
          }
        }

        smax = 1.0 / A[d_j + iy];
        for (iy = 0; iy < 6; iy++) {
          i = iy + jBcol;
          X[i] *= smax;
        }
      }

      for (d_j = 4; d_j >= 0; d_j--) {
        jBcol = 6 * d_j;
        iy = 5 * d_j - 1;
        for (ix = d_j + 2; ix < 6; ix++) {
          kBcol = (ix - 1) * 6;
          if (A[ix + iy] != 0.0) {
            for (c_ix = 0; c_ix < 6; c_ix++) {
              i = c_ix + jBcol;
              X[i] -= A[ix + iy] * X[c_ix + kBcol];
            }
          }
        }
      }

      for (d_j = 3; d_j >= 0; d_j--) {
        ipiv_0 = ipiv[d_j];
        if (d_j + 1 != ipiv_0) {
          for (iy = 0; iy < 6; iy++) {
            jBcol = 6 * d_j + iy;
            smax = X[jBcol];
            i = (ipiv_0 - 1) * 6 + iy;
            X[jBcol] = X[i];
            X[i] = smax;
          }
        }
      }

      /* SignalConversion generated from: '<S8>/ SFunction ' incorporates:
       *  UnitDelay: '<S2>/Unit Delay1'
       */
      /* '<S8>:1:10' */
      tmp_3[0] = heli_q8_B.pe[0];
      tmp_3[1] = heli_q8_B.Sum7;
      tmp_3[2] = heli_q8_B.pe[1];
      tmp_3[3] = heli_q8_B.Sum5;
      tmp_3[4] = heli_q8_B.Sum2;
      for (d_j = 0; d_j < 5; d_j++) {
        tmp_4[d_j] = 0.0;
        for (iy = 0; iy < 6; iy++) {
          tmp_4[d_j] += heli_q8_P.C_d[5 * iy + d_j] * heli_q8_B.x_k[iy];
        }

        tmp_5[d_j] = tmp_3[d_j] - tmp_4[d_j];
      }

      /* '<S8>:1:13' */
      /* '<S8>:1:14' */
      /* '<S8>:1:15' */
      for (d_j = 0; d_j < 6; d_j++) {
        rtb_euler_rates_tmp = 0.0;
        for (iy = 0; iy < 5; iy++) {
          rtb_euler_rates_tmp += X[6 * iy + d_j] * tmp_5[iy];
        }

        heli_q8_B.x_hat[d_j] = heli_q8_B.x_k[d_j] + rtb_euler_rates_tmp;
        for (iy = 0; iy < 6; iy++) {
          rtb_euler_rates_tmp = 0.0;
          for (jBcol = 0; jBcol < 5; jBcol++) {
            rtb_euler_rates_tmp += X[6 * jBcol + d_j] * heli_q8_P.C_d[5 * iy +
              jBcol];
          }

          i = 6 * iy + d_j;
          I_LC[i] = (real_T)b_I[i] - rtb_euler_rates_tmp;
        }

        for (iy = 0; iy < 6; iy++) {
          i = d_j + 6 * iy;
          I_LC_0[i] = 0.0;
          for (jBcol = 0; jBcol < 6; jBcol++) {
            I_LC_0[i] += I_LC[6 * jBcol + d_j] * heli_q8_B.P_k[6 * iy + jBcol];
          }
        }

        for (iy = 0; iy < 5; iy++) {
          i = d_j + 6 * iy;
          A_tmp[i] = 0.0;
          for (jBcol = 0; jBcol < 5; jBcol++) {
            A_tmp[i] += X[6 * jBcol + d_j] * heli_q8_P.R_d[5 * iy + jBcol];
          }
        }
      }

      for (d_j = 0; d_j < 6; d_j++) {
        for (iy = 0; iy < 6; iy++) {
          i = d_j + 6 * iy;
          I_LC_1[i] = 0.0;
          for (jBcol = 0; jBcol < 6; jBcol++) {
            I_LC_1[i] += I_LC_0[6 * jBcol + d_j] * I_LC[6 * jBcol + iy];
          }

          X_0[i] = 0.0;
          for (jBcol = 0; jBcol < 5; jBcol++) {
            X_0[i] += A_tmp[6 * jBcol + d_j] * X[6 * jBcol + iy];
          }
        }
      }

      for (d_j = 0; d_j < 36; d_j++) {
        heli_q8_B.P_hat[d_j] = I_LC_1[d_j] + X_0[d_j];
      }
    } else {
      /* '<S8>:1:18' */
      for (i = 0; i < 6; i++) {
        heli_q8_B.x_hat[i] = heli_q8_B.x_k[i];
      }

      /* '<S8>:1:19' */
      memcpy(&heli_q8_B.P_hat[0], &heli_q8_B.P_k[0], 36U * sizeof(real_T));
    }

    /* '<S8>:1:21' */
    for (d_j = 0; d_j < 6; d_j++) {
      heli_q8_B.P_cov_diag[d_j] = heli_q8_B.P_hat[6 * d_j + d_j];
    }

    /* End of MATLAB Function: '<S2>/Correction' */

    /* Gain: '<S3>/Pitch: Count to rad' */
    heli_q8_B.PitchCounttorad = heli_q8_P.PitchCounttorad_Gain *
      rtb_HILReadEncoderTimebase_o2;

    /* Gain: '<S3>/Elevation: Count to rad' */
    heli_q8_B.ElevationCounttorad = heli_q8_P.ElevationCounttorad_Gain *
      rtb_DeadZoney;
  }

  /* TransferFcn: '<S3>/Pitch: Transfer Fcn' */
  heli_q8_B.PitchTransferFcn = 0.0;
  heli_q8_B.PitchTransferFcn += heli_q8_P.PitchTransferFcn_C *
    heli_q8_X.PitchTransferFcn_CSTATE;
  heli_q8_B.PitchTransferFcn += heli_q8_P.PitchTransferFcn_D *
    heli_q8_B.PitchCounttorad;

  /* TransferFcn: '<S3>/Elevation: Transfer Fcn' */
  heli_q8_B.ElevationTransferFcn = 0.0;
  heli_q8_B.ElevationTransferFcn += heli_q8_P.ElevationTransferFcn_C *
    heli_q8_X.ElevationTransferFcn_CSTATE;
  heli_q8_B.ElevationTransferFcn += heli_q8_P.ElevationTransferFcn_D *
    heli_q8_B.ElevationCounttorad;
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    /* Gain: '<S3>/Travel: Count to rad' */
    heli_q8_B.TravelCounttorad = heli_q8_P.TravelCounttorad_Gain *
      rtb_HILReadEncoderTimebase_o1;
  }

  /* Gain: '<S3>/Innvertering2' incorporates:
   *  TransferFcn: '<S3>/Travel: Transfer Fcn'
   */
  heli_q8_B.Innvertering2 = (heli_q8_P.TravelTransferFcn_C *
    heli_q8_X.TravelTransferFcn_CSTATE + heli_q8_P.TravelTransferFcn_D *
    heli_q8_B.TravelCounttorad) * heli_q8_P.Innvertering2_Gain;

  /* RateTransition: '<S5>/Rate Transition: x' */
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    /* Sum: '<S3>/Sum' incorporates:
     *  Constant: '<S3>/Constant_Elevation'
     */
    heli_q8_B.Sum = heli_q8_B.ElevationCounttorad -
      heli_q8_P.Constant_Elevation_Value;
    if (heli_q8_M->Timing.RateInteraction.TID1_2) {
      /* RateTransition: '<S5>/Rate Transition: x' */
      heli_q8_B.RateTransitionx = heli_q8_DW.RateTransitionx_Buffer0;
    }

    /* DeadZone: '<S5>/Dead Zone: x' */
    if (heli_q8_B.RateTransitionx > heli_q8_P.DeadZonex_End) {
      /* DeadZone: '<S5>/Dead Zone: y' */
      rtb_DeadZoney = heli_q8_B.RateTransitionx - heli_q8_P.DeadZonex_End;
    } else if (heli_q8_B.RateTransitionx >= heli_q8_P.DeadZonex_Start) {
      /* DeadZone: '<S5>/Dead Zone: y' */
      rtb_DeadZoney = 0.0;
    } else {
      /* DeadZone: '<S5>/Dead Zone: y' */
      rtb_DeadZoney = heli_q8_B.RateTransitionx - heli_q8_P.DeadZonex_Start;
    }

    /* End of DeadZone: '<S5>/Dead Zone: x' */

    /* Gain: '<S5>/Joystick_gain_x' incorporates:
     *  Gain: '<S5>/Gain: x'
     */
    heli_q8_B.Joystick_gain_x = heli_q8_P.Gainx_Gain * rtb_DeadZoney *
      heli_q8_P.Joystick_gain_x;
  }

  /* End of RateTransition: '<S5>/Rate Transition: x' */

  /* Step: '<Root>/Step' */
  if (heli_q8_M->Timing.t[0] < heli_q8_P.Step_Time) {
    rtb_euler_rates_tmp = heli_q8_P.Step_Y0;
  } else {
    rtb_euler_rates_tmp = heli_q8_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* Sum: '<Root>/Sum' */
  heli_q8_B.Sum_n = rtb_euler_rates_tmp + heli_q8_B.Joystick_gain_x;

  /* Gain: '<S6>/Gain' */
  smax = heli_q8_P.Gain_Gain * heli_q8_B.Sum_n;

  /* RateTransition: '<S5>/Rate Transition: y' */
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    if (heli_q8_M->Timing.RateInteraction.TID1_2) {
      /* RateTransition: '<S5>/Rate Transition: y' */
      heli_q8_B.RateTransitiony = heli_q8_DW.RateTransitiony_Buffer0;
    }

    /* DeadZone: '<S5>/Dead Zone: y' */
    if (heli_q8_B.RateTransitiony > heli_q8_P.DeadZoney_End) {
      /* DeadZone: '<S5>/Dead Zone: y' */
      rtb_DeadZoney = heli_q8_B.RateTransitiony - heli_q8_P.DeadZoney_End;
    } else if (heli_q8_B.RateTransitiony >= heli_q8_P.DeadZoney_Start) {
      /* DeadZone: '<S5>/Dead Zone: y' */
      rtb_DeadZoney = 0.0;
    } else {
      /* DeadZone: '<S5>/Dead Zone: y' */
      rtb_DeadZoney = heli_q8_B.RateTransitiony - heli_q8_P.DeadZoney_Start;
    }

    /* End of DeadZone: '<S5>/Dead Zone: y' */

    /* Gain: '<S5>/Joystick_gain_y' incorporates:
     *  Gain: '<S5>/Gain: y'
     */
    heli_q8_B.Joystick_gain_y = heli_q8_P.Gainy_Gain * rtb_DeadZoney *
      heli_q8_P.Joystick_gain_y;

    /* Gain: '<S6>/Gain1' */
    heli_q8_B.e_c_dot = heli_q8_P.Gain1_Gain_b * heli_q8_B.Joystick_gain_y;
  }

  /* End of RateTransition: '<S5>/Rate Transition: y' */

  /* SignalConversion generated from: '<S6>/Gain3' incorporates:
   *  Integrator: '<S6>/Integrator'
   *  Integrator: '<S6>/Integrator1'
   */
  tmp_3[2] = heli_q8_B.x_hat[3];
  tmp_3[3] = heli_q8_X.Integrator_CSTATE;
  tmp_3[4] = heli_q8_X.Integrator1_CSTATE;
  tmp_3[0] = heli_q8_B.x_hat[0];

  /* Gain: '<S6>/Gain2' incorporates:
   *  SignalConversion generated from: '<S6>/Gain2'
   */
  tmp_0[0] = heli_q8_P.F[0] * smax + heli_q8_P.F[2] * heli_q8_B.e_c_dot;

  /* SignalConversion generated from: '<S6>/Gain3' */
  tmp_3[1] = heli_q8_B.x_hat[1];

  /* Gain: '<S6>/Gain2' incorporates:
   *  SignalConversion generated from: '<S6>/Gain2'
   */
  tmp_0[1] = heli_q8_P.F[1] * smax;
  tmp_0[1] += heli_q8_P.F[3] * heli_q8_B.e_c_dot;
  for (d_j = 0; d_j < 2; d_j++) {
    /* Gain: '<S6>/Gain3' */
    tmp_1[d_j] = 0.0;
    for (iy = 0; iy < 5; iy++) {
      tmp_1[d_j] += heli_q8_P.K[(iy << 1) + d_j] * tmp_3[iy];
    }

    /* End of Gain: '<S6>/Gain3' */

    /* Sum: '<S6>/Sum5' */
    heli_q8_B.u[d_j] = tmp_0[d_j] - tmp_1[d_j];
  }

  /* Sum: '<Root>/Sum6' incorporates:
   *  Constant: '<Root>/Constant3'
   */
  heli_q8_B.V_s = heli_q8_B.u[0] + heli_q8_P.v_s0;
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    /* Gain: '<S3>/Innvertering' */
    heli_q8_B.Innvertering = heli_q8_P.Innvertering_Gain *
      heli_q8_B.TravelCounttorad;

    /* SignalConversion generated from: '<Root>/To File' */
    rtb_TmpSignalConversionAtToFile[0] = heli_q8_B.Sum_n;
    rtb_TmpSignalConversionAtToFile[1] = heli_q8_B.u[1];
    rtb_TmpSignalConversionAtToFile[2] = heli_q8_B.V_s;
    rtb_TmpSignalConversionAtToFile[3] = heli_q8_B.Innvertering;
    rtb_TmpSignalConversionAtToFile[4] = heli_q8_B.Innvertering2;
    rtb_TmpSignalConversionAtToFile[5] = heli_q8_B.PitchCounttorad;
    rtb_TmpSignalConversionAtToFile[6] = heli_q8_B.PitchTransferFcn;
    rtb_TmpSignalConversionAtToFile[7] = heli_q8_B.Sum;
    rtb_TmpSignalConversionAtToFile[8] = heli_q8_B.ElevationTransferFcn;
    rtb_TmpSignalConversionAtToFile[11] = heli_q8_B.x_hat[3];
    rtb_TmpSignalConversionAtToFile[9] = heli_q8_B.x_hat[0];
    rtb_TmpSignalConversionAtToFile[12] = heli_q8_B.pe[0];
    rtb_TmpSignalConversionAtToFile[10] = heli_q8_B.x_hat[1];
    rtb_TmpSignalConversionAtToFile[13] = heli_q8_B.pe[1];
    rtb_TmpSignalConversionAtToFile[14] = heli_q8_B.Gain1[0];
    rtb_TmpSignalConversionAtToFile[15] = heli_q8_B.Gain1[1];
    rtb_TmpSignalConversionAtToFile[16] = heli_q8_B.Gain1[2];
    rtb_TmpSignalConversionAtToFile[17] = heli_q8_B.Sum7;
    rtb_TmpSignalConversionAtToFile[18] = heli_q8_B.Sum5;
    rtb_TmpSignalConversionAtToFile[19] = heli_q8_B.Sum2;

    /* ToFile: '<Root>/To File' */
    if (rtmIsMajorTimeStep(heli_q8_M)) {
      if (rtmIsMajorTimeStep(heli_q8_M) ) {
        {
          if (!(++heli_q8_DW.ToFile_IWORK.Decimation % 2) &&
              (heli_q8_DW.ToFile_IWORK.Count * (20 + 1)) + 1 < 100000000 ) {
            FILE *fp = (FILE *) heli_q8_DW.ToFile_PWORK.FilePtr;
            if (fp != (NULL)) {
              real_T u[20 + 1];
              heli_q8_DW.ToFile_IWORK.Decimation = 0;
              u[0] = heli_q8_M->Timing.t[1];
              u[1] = rtb_TmpSignalConversionAtToFile[0];
              u[2] = rtb_TmpSignalConversionAtToFile[1];
              u[3] = rtb_TmpSignalConversionAtToFile[2];
              u[4] = rtb_TmpSignalConversionAtToFile[3];
              u[5] = rtb_TmpSignalConversionAtToFile[4];
              u[6] = rtb_TmpSignalConversionAtToFile[5];
              u[7] = rtb_TmpSignalConversionAtToFile[6];
              u[8] = rtb_TmpSignalConversionAtToFile[7];
              u[9] = rtb_TmpSignalConversionAtToFile[8];
              u[10] = rtb_TmpSignalConversionAtToFile[9];
              u[11] = rtb_TmpSignalConversionAtToFile[10];
              u[12] = rtb_TmpSignalConversionAtToFile[11];
              u[13] = rtb_TmpSignalConversionAtToFile[12];
              u[14] = rtb_TmpSignalConversionAtToFile[13];
              u[15] = rtb_TmpSignalConversionAtToFile[14];
              u[16] = rtb_TmpSignalConversionAtToFile[15];
              u[17] = rtb_TmpSignalConversionAtToFile[16];
              u[18] = rtb_TmpSignalConversionAtToFile[17];
              u[19] = rtb_TmpSignalConversionAtToFile[18];
              u[20] = rtb_TmpSignalConversionAtToFile[19];
              if (fwrite(u, sizeof(real_T), 20 + 1, fp) != 20 + 1) {
                rtmSetErrorStatus(heli_q8_M,
                                  "Error writing to MAT-file IMU09.mat");
                return;
              }

              if (((++heli_q8_DW.ToFile_IWORK.Count) * (20 + 1))+1 >= 100000000)
              {
                (void)fprintf(stdout,
                              "*** The ToFile block will stop logging data before\n"
                              "    the simulation has ended, because it has reached\n"
                              "    the maximum number of elements (100000000)\n"
                              "    allowed in MAT-file IMU09.mat.\n");
              }
            }
          }
        }
      }
    }

    /* SignalConversion generated from: '<S2>/To File1' */
    rtb_TmpSignalConversionAtToFi_n[0] = heli_q8_B.u[0];
    rtb_TmpSignalConversionAtToFi_n[1] = heli_q8_B.u[1];
    rtb_TmpSignalConversionAtToFi_n[2] = heli_q8_B.pe[0];
    rtb_TmpSignalConversionAtToFi_n[3] = heli_q8_B.Sum7;
    rtb_TmpSignalConversionAtToFi_n[4] = heli_q8_B.pe[1];
    rtb_TmpSignalConversionAtToFi_n[5] = heli_q8_B.Sum5;
    rtb_TmpSignalConversionAtToFi_n[6] = heli_q8_B.Sum2;
    for (i = 0; i < 6; i++) {
      rtb_TmpSignalConversionAtToFi_n[i + 7] = heli_q8_B.x_hat[i];
      rtb_TmpSignalConversionAtToFi_n[i + 13] = heli_q8_B.P_cov_diag[i];
    }

    rtb_TmpSignalConversionAtToFi_n[19] = heli_q8_B.ManualSwitch;
    rtb_TmpSignalConversionAtToFi_n[20] = heli_q8_B.Sum_n;
    rtb_TmpSignalConversionAtToFi_n[21] = heli_q8_B.u[1];
    rtb_TmpSignalConversionAtToFi_n[22] = heli_q8_B.V_s;
    rtb_TmpSignalConversionAtToFi_n[23] = heli_q8_B.Innvertering;
    rtb_TmpSignalConversionAtToFi_n[24] = heli_q8_B.Innvertering2;
    rtb_TmpSignalConversionAtToFi_n[25] = heli_q8_B.PitchCounttorad;
    rtb_TmpSignalConversionAtToFi_n[26] = heli_q8_B.PitchTransferFcn;
    rtb_TmpSignalConversionAtToFi_n[27] = heli_q8_B.Sum;
    rtb_TmpSignalConversionAtToFi_n[28] = heli_q8_B.ElevationTransferFcn;

    /* End of SignalConversion generated from: '<S2>/To File1' */

    /* ToFile: '<S2>/To File1' */
    if (rtmIsMajorTimeStep(heli_q8_M)) {
      if (rtmIsMajorTimeStep(heli_q8_M) ) {
        {
          if (!(++heli_q8_DW.ToFile1_IWORK.Decimation % 2) &&
              (heli_q8_DW.ToFile1_IWORK.Count * (29 + 1)) + 1 < 100000000 ) {
            FILE *fp = (FILE *) heli_q8_DW.ToFile1_PWORK.FilePtr;
            if (fp != (NULL)) {
              real_T u[29 + 1];
              heli_q8_DW.ToFile1_IWORK.Decimation = 0;
              u[0] = heli_q8_M->Timing.t[1];
              u[1] = rtb_TmpSignalConversionAtToFi_n[0];
              u[2] = rtb_TmpSignalConversionAtToFi_n[1];
              u[3] = rtb_TmpSignalConversionAtToFi_n[2];
              u[4] = rtb_TmpSignalConversionAtToFi_n[3];
              u[5] = rtb_TmpSignalConversionAtToFi_n[4];
              u[6] = rtb_TmpSignalConversionAtToFi_n[5];
              u[7] = rtb_TmpSignalConversionAtToFi_n[6];
              u[8] = rtb_TmpSignalConversionAtToFi_n[7];
              u[9] = rtb_TmpSignalConversionAtToFi_n[8];
              u[10] = rtb_TmpSignalConversionAtToFi_n[9];
              u[11] = rtb_TmpSignalConversionAtToFi_n[10];
              u[12] = rtb_TmpSignalConversionAtToFi_n[11];
              u[13] = rtb_TmpSignalConversionAtToFi_n[12];
              u[14] = rtb_TmpSignalConversionAtToFi_n[13];
              u[15] = rtb_TmpSignalConversionAtToFi_n[14];
              u[16] = rtb_TmpSignalConversionAtToFi_n[15];
              u[17] = rtb_TmpSignalConversionAtToFi_n[16];
              u[18] = rtb_TmpSignalConversionAtToFi_n[17];
              u[19] = rtb_TmpSignalConversionAtToFi_n[18];
              u[20] = rtb_TmpSignalConversionAtToFi_n[19];
              u[21] = rtb_TmpSignalConversionAtToFi_n[20];
              u[22] = rtb_TmpSignalConversionAtToFi_n[21];
              u[23] = rtb_TmpSignalConversionAtToFi_n[22];
              u[24] = rtb_TmpSignalConversionAtToFi_n[23];
              u[25] = rtb_TmpSignalConversionAtToFi_n[24];
              u[26] = rtb_TmpSignalConversionAtToFi_n[25];
              u[27] = rtb_TmpSignalConversionAtToFi_n[26];
              u[28] = rtb_TmpSignalConversionAtToFi_n[27];
              u[29] = rtb_TmpSignalConversionAtToFi_n[28];
              if (fwrite(u, sizeof(real_T), 29 + 1, fp) != 29 + 1) {
                rtmSetErrorStatus(heli_q8_M,
                                  "Error writing to MAT-file KalTest08.mat");
                return;
              }

              if (((++heli_q8_DW.ToFile1_IWORK.Count) * (29 + 1))+1 >= 100000000)
              {
                (void)fprintf(stdout,
                              "*** The ToFile block will stop logging data before\n"
                              "    the simulation has ended, because it has reached\n"
                              "    the maximum number of elements (100000000)\n"
                              "    allowed in MAT-file KalTest08.mat.\n");
              }
            }
          }
        }
      }
    }
  }

  /* MATLAB Function: '<S2>/Prediction' */
  /* MATLAB Function 'ESTIMATOR/Prediction': '<S9>:1' */
  /* '<S9>:1:3' */
  /* '<S9>:1:6' */
  for (d_j = 0; d_j < 6; d_j++) {
    tmp_2[d_j] = 0.0;
    for (iy = 0; iy < 6; iy++) {
      jBcol = 6 * iy + d_j;
      I_LC[jBcol] = 0.0;
      for (i = 0; i < 6; i++) {
        I_LC[jBcol] += heli_q8_P.A_d[6 * i + d_j] * heli_q8_B.P_hat[6 * iy + i];
      }

      tmp_2[d_j] += heli_q8_P.A_d[jBcol] * heli_q8_B.x_hat[iy];
    }

    heli_q8_B.x_bar_next[d_j] = tmp_2[d_j] + (heli_q8_P.B_d[d_j + 6] *
      heli_q8_B.u[1] + heli_q8_P.B_d[d_j] * heli_q8_B.u[0]);
    for (iy = 0; iy < 6; iy++) {
      rtb_euler_rates_tmp = 0.0;
      for (jBcol = 0; jBcol < 6; jBcol++) {
        rtb_euler_rates_tmp += I_LC[6 * jBcol + d_j] * heli_q8_P.A_d[6 * jBcol +
          iy];
      }

      i = 6 * iy + d_j;
      heli_q8_B.P_bar_next[i] = heli_q8_P.Q_d[i] + rtb_euler_rates_tmp;
    }
  }

  /* End of MATLAB Function: '<S2>/Prediction' */
  if (rtmIsMajorTimeStep(heli_q8_M)) {
  }

  /* Gain: '<S1>/Front gain' incorporates:
   *  Sum: '<S1>/Add'
   */
  rtb_euler_rates_tmp = (heli_q8_B.V_s - heli_q8_B.u[1]) *
    heli_q8_P.Frontgain_Gain;

  /* Saturate: '<S3>/Front motor: Saturation' */
  if (rtb_euler_rates_tmp > heli_q8_P.FrontmotorSaturation_UpperSat) {
    /* Saturate: '<S3>/Front motor: Saturation' */
    heli_q8_B.FrontmotorSaturation = heli_q8_P.FrontmotorSaturation_UpperSat;
  } else if (rtb_euler_rates_tmp < heli_q8_P.FrontmotorSaturation_LowerSat) {
    /* Saturate: '<S3>/Front motor: Saturation' */
    heli_q8_B.FrontmotorSaturation = heli_q8_P.FrontmotorSaturation_LowerSat;
  } else {
    /* Saturate: '<S3>/Front motor: Saturation' */
    heli_q8_B.FrontmotorSaturation = rtb_euler_rates_tmp;
  }

  /* End of Saturate: '<S3>/Front motor: Saturation' */

  /* Gain: '<S1>/Back gain' incorporates:
   *  Sum: '<S1>/Subtract'
   */
  rtb_euler_rates_tmp = (heli_q8_B.V_s + heli_q8_B.u[1]) *
    heli_q8_P.Backgain_Gain;

  /* Saturate: '<S3>/Back motor: Saturation' */
  if (rtb_euler_rates_tmp > heli_q8_P.BackmotorSaturation_UpperSat) {
    /* Saturate: '<S3>/Back motor: Saturation' */
    heli_q8_B.BackmotorSaturation = heli_q8_P.BackmotorSaturation_UpperSat;
  } else if (rtb_euler_rates_tmp < heli_q8_P.BackmotorSaturation_LowerSat) {
    /* Saturate: '<S3>/Back motor: Saturation' */
    heli_q8_B.BackmotorSaturation = heli_q8_P.BackmotorSaturation_LowerSat;
  } else {
    /* Saturate: '<S3>/Back motor: Saturation' */
    heli_q8_B.BackmotorSaturation = rtb_euler_rates_tmp;
  }

  /* End of Saturate: '<S3>/Back motor: Saturation' */
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    /* S-Function (hil_write_analog_block): '<S3>/HIL Write Analog' */

    /* S-Function Block: heli_q8/Heli 3D/HIL Write Analog (hil_write_analog_block) */
    {
      t_error result;
      heli_q8_DW.HILWriteAnalog_Buffer[0] = heli_q8_B.FrontmotorSaturation;
      heli_q8_DW.HILWriteAnalog_Buffer[1] = heli_q8_B.BackmotorSaturation;
      result = hil_write_analog(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILWriteAnalog_channels, 2, &heli_q8_DW.HILWriteAnalog_Buffer
        [0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
      }
    }

    /* Outputs for Enabled SubSystem: '<S11>/Skip to next line' incorporates:
     *  EnablePort: '<S19>/Enable'
     */
    if (heli_q8_B.StreamFormattedRead1_o10) {
      /* S-Function (stream_formatted_read_block): '<S19>/Stream Formatted Read' incorporates:
       *  S-Function (stream_call_block): '<S11>/Stream Call2'
       *  S-Function (stream_formatted_read_block): '<S11>/Stream Formatted Read1'
       */
      {
        if (((t_stream_ptr)rtb_StreamCall2_o1) != NULL) {
          stream_scan_utf8_char_array(*((t_stream_ptr)rtb_StreamCall2_o1),
            heli_q8_P.StreamFormattedRead_MaxUnits, &rtb_StreamFormattedRead_o2,
            " %*[^\r]"
            );
        } else {
          rtb_StreamFormattedRead_o2 = 0;
        }
      }

      if (rtmIsMajorTimeStep(heli_q8_M)) {
        srUpdateBC(heli_q8_DW.Skiptonextline_SubsysRanBC);
      }
    }

    /* End of Outputs for SubSystem: '<S11>/Skip to next line' */

    /* S-Function (stop_with_error_block): '<S11>/Stop with Error' */

    /* S-Function Block: heli_q8/IMU Block/IMU_BT/Stop with Error (stop_with_error_block) */
    {
      if (rtb_StreamCall2_o3 < 0) {
        msg_get_error_messageA(NULL, rtb_StreamCall2_o3, _rt_error_message,
          sizeof(_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }
  }

  /* Sum: '<S6>/Sum' */
  heli_q8_B.gamma_dot = smax - heli_q8_B.x_hat[0];
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    /* Sum: '<S6>/Sum1' */
    heli_q8_B.Zeta_dot = heli_q8_B.e_c_dot - heli_q8_B.x_hat[3];
  }
}

/* Model update function for TID0 */
void heli_q8_update0(void)             /* Sample time: [0.0s, 0.0s] */
{
  int32_T i;
  if (rtmIsMajorTimeStep(heli_q8_M)) {
    /* Update for UnitDelay: '<S2>/Unit Delay' */
    for (i = 0; i < 6; i++) {
      heli_q8_DW.UnitDelay_DSTATE[i] = heli_q8_B.x_bar_next[i];
    }

    /* End of Update for UnitDelay: '<S2>/Unit Delay' */

    /* Update for UnitDelay: '<S2>/Unit Delay1' */
    memcpy(&heli_q8_DW.UnitDelay1_DSTATE[0], &heli_q8_B.P_bar_next[0], 36U *
           sizeof(real_T));

    /* Update for UnitDelay: '<S13>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_i = heli_q8_B.StreamFormattedRead1_o2;

    /* Update for UnitDelay: '<S14>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_o = heli_q8_B.StreamFormattedRead1_o3;

    /* Update for UnitDelay: '<S15>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_od = heli_q8_B.StreamFormattedRead1_o4;

    /* Update for UnitDelay: '<S16>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_l = heli_q8_B.StreamFormattedRead1_o5;

    /* Update for UnitDelay: '<S17>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_e = heli_q8_B.StreamFormattedRead1_o6;

    /* Update for UnitDelay: '<S18>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_ei = heli_q8_B.StreamFormattedRead1_o7;
  }

  if (rtmIsMajorTimeStep(heli_q8_M)) {
    rt_ertODEUpdateContinuousStates(&heli_q8_M->solverInfo);
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++heli_q8_M->Timing.clockTick0)) {
    ++heli_q8_M->Timing.clockTickH0;
  }

  heli_q8_M->Timing.t[0] = rtsiGetSolverStopTime(&heli_q8_M->solverInfo);

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick1"
   * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++heli_q8_M->Timing.clockTick1)) {
    ++heli_q8_M->Timing.clockTickH1;
  }

  heli_q8_M->Timing.t[1] = heli_q8_M->Timing.clockTick1 *
    heli_q8_M->Timing.stepSize1 + heli_q8_M->Timing.clockTickH1 *
    heli_q8_M->Timing.stepSize1 * 4294967296.0;
}

/* Derivatives for root system: '<Root>' */
void heli_q8_derivatives(void)
{
  XDot_heli_q8_T *_rtXdot;
  _rtXdot = ((XDot_heli_q8_T *) heli_q8_M->derivs);

  /* Derivatives for TransferFcn: '<S3>/Pitch: Transfer Fcn' */
  _rtXdot->PitchTransferFcn_CSTATE = 0.0;
  _rtXdot->PitchTransferFcn_CSTATE += heli_q8_P.PitchTransferFcn_A *
    heli_q8_X.PitchTransferFcn_CSTATE;
  _rtXdot->PitchTransferFcn_CSTATE += heli_q8_B.PitchCounttorad;

  /* Derivatives for TransferFcn: '<S3>/Elevation: Transfer Fcn' */
  _rtXdot->ElevationTransferFcn_CSTATE = 0.0;
  _rtXdot->ElevationTransferFcn_CSTATE += heli_q8_P.ElevationTransferFcn_A *
    heli_q8_X.ElevationTransferFcn_CSTATE;
  _rtXdot->ElevationTransferFcn_CSTATE += heli_q8_B.ElevationCounttorad;

  /* Derivatives for TransferFcn: '<S3>/Travel: Transfer Fcn' */
  _rtXdot->TravelTransferFcn_CSTATE = 0.0;
  _rtXdot->TravelTransferFcn_CSTATE += heli_q8_P.TravelTransferFcn_A *
    heli_q8_X.TravelTransferFcn_CSTATE;
  _rtXdot->TravelTransferFcn_CSTATE += heli_q8_B.TravelCounttorad;

  /* Derivatives for Integrator: '<S6>/Integrator' */
  _rtXdot->Integrator_CSTATE = heli_q8_B.gamma_dot;

  /* Derivatives for Integrator: '<S6>/Integrator1' */
  _rtXdot->Integrator1_CSTATE = heli_q8_B.Zeta_dot;
}

/* Model output function for TID2 */
void heli_q8_output2(void)             /* Sample time: [0.01s, 0.0s] */
{
  /* local block i/o variables */
  real_T rtb_GameController_o4;
  real_T rtb_GameController_o5;

  /* S-Function (game_controller_block): '<S5>/Game Controller' */

  /* S-Function Block: heli_q8/Joystick/Game Controller (game_controller_block) */
  {
    if (heli_q8_P.GameController_Enabled) {
      t_game_controller_states state;
      t_boolean new_data;
      t_error result;
      result = game_controller_poll(heli_q8_DW.GameController_Controller, &state,
        &new_data);
      if (result < 0) {
        new_data = false;
      }

      rtb_GameController_o4 = state.x;
      rtb_GameController_o5 = state.y;
    } else {
      rtb_GameController_o4 = 0;
      rtb_GameController_o5 = 0;
    }
  }

  /* RateTransition: '<S5>/Rate Transition: x' */
  heli_q8_DW.RateTransitionx_Buffer0 = rtb_GameController_o4;

  /* RateTransition: '<S5>/Rate Transition: y' */
  heli_q8_DW.RateTransitiony_Buffer0 = rtb_GameController_o5;
}

/* Model update function for TID2 */
void heli_q8_update2(void)             /* Sample time: [0.01s, 0.0s] */
{
  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++heli_q8_M->Timing.clockTick2)) {
    ++heli_q8_M->Timing.clockTickH2;
  }

  heli_q8_M->Timing.t[2] = heli_q8_M->Timing.clockTick2 *
    heli_q8_M->Timing.stepSize2 + heli_q8_M->Timing.clockTickH2 *
    heli_q8_M->Timing.stepSize2 * 4294967296.0;
}

/* Model output wrapper function for compatibility with a static main program */
void heli_q8_output(int_T tid)
{
  switch (tid) {
   case 0 :
    heli_q8_output0();
    break;

   case 2 :
    heli_q8_output2();
    break;

   default :
    break;
  }
}

/* Model update wrapper function for compatibility with a static main program */
void heli_q8_update(int_T tid)
{
  switch (tid) {
   case 0 :
    heli_q8_update0();
    break;

   case 2 :
    heli_q8_update2();
    break;

   default :
    break;
  }
}

/* Model initialize function */
void heli_q8_initialize(void)
{
  /* Start for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: heli_q8/HIL Initialize (hil_initialize_block) */
  {
    t_int result;
    t_boolean is_switching;
    result = hil_open("q8_usb", "0", &heli_q8_DW.HILInitialize_Card);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(heli_q8_M, _rt_error_message);
      return;
    }

    is_switching = false;
    result = hil_set_card_specific_options(heli_q8_DW.HILInitialize_Card,
      "update_rate=normal;decimation=1", 32);
    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(heli_q8_M, _rt_error_message);
      return;
    }

    result = hil_watchdog_clear(heli_q8_DW.HILInitialize_Card);
    if (result < 0 && result != -QERR_HIL_WATCHDOG_CLEAR) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(heli_q8_M, _rt_error_message);
      return;
    }

    if ((heli_q8_P.HILInitialize_AIPStart && !is_switching) ||
        (heli_q8_P.HILInitialize_AIPEnter && is_switching)) {
      {
        int_T i1;
        real_T *dw_AIMinimums = &heli_q8_DW.HILInitialize_AIMinimums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AIMinimums[i1] = (heli_q8_P.HILInitialize_AILow);
        }
      }

      {
        int_T i1;
        real_T *dw_AIMaximums = &heli_q8_DW.HILInitialize_AIMaximums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AIMaximums[i1] = heli_q8_P.HILInitialize_AIHigh;
        }
      }

      result = hil_set_analog_input_ranges(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_AIChannels, 8U,
        &heli_q8_DW.HILInitialize_AIMinimums[0],
        &heli_q8_DW.HILInitialize_AIMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }

    if ((heli_q8_P.HILInitialize_AOPStart && !is_switching) ||
        (heli_q8_P.HILInitialize_AOPEnter && is_switching)) {
      {
        int_T i1;
        real_T *dw_AOMinimums = &heli_q8_DW.HILInitialize_AOMinimums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOMinimums[i1] = (heli_q8_P.HILInitialize_AOLow);
        }
      }

      {
        int_T i1;
        real_T *dw_AOMaximums = &heli_q8_DW.HILInitialize_AOMaximums[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOMaximums[i1] = heli_q8_P.HILInitialize_AOHigh;
        }
      }

      result = hil_set_analog_output_ranges(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_AOChannels, 8U,
        &heli_q8_DW.HILInitialize_AOMinimums[0],
        &heli_q8_DW.HILInitialize_AOMaximums[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }

    if ((heli_q8_P.HILInitialize_AOStart && !is_switching) ||
        (heli_q8_P.HILInitialize_AOEnter && is_switching)) {
      {
        int_T i1;
        real_T *dw_AOVoltages = &heli_q8_DW.HILInitialize_AOVoltages[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOVoltages[i1] = heli_q8_P.HILInitialize_AOInitial;
        }
      }

      result = hil_write_analog(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_AOChannels, 8U,
        &heli_q8_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }

    if (heli_q8_P.HILInitialize_AOReset) {
      {
        int_T i1;
        real_T *dw_AOVoltages = &heli_q8_DW.HILInitialize_AOVoltages[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOVoltages[i1] = heli_q8_P.HILInitialize_AOWatchdog;
        }
      }

      result = hil_watchdog_set_analog_expiration_state
        (heli_q8_DW.HILInitialize_Card, heli_q8_P.HILInitialize_AOChannels, 8U,
         &heli_q8_DW.HILInitialize_AOVoltages[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }

    if ((heli_q8_P.HILInitialize_EIPStart && !is_switching) ||
        (heli_q8_P.HILInitialize_EIPEnter && is_switching)) {
      {
        int_T i1;
        int32_T *dw_QuadratureModes = &heli_q8_DW.HILInitialize_QuadratureModes
          [0];
        for (i1=0; i1 < 8; i1++) {
          dw_QuadratureModes[i1] = heli_q8_P.HILInitialize_EIQuadrature;
        }
      }

      result = hil_set_encoder_quadrature_mode(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_EIChannels, 8U, (t_encoder_quadrature_mode *)
        &heli_q8_DW.HILInitialize_QuadratureModes[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }

    if ((heli_q8_P.HILInitialize_EIStart && !is_switching) ||
        (heli_q8_P.HILInitialize_EIEnter && is_switching)) {
      {
        int_T i1;
        int32_T *dw_InitialEICounts = &heli_q8_DW.HILInitialize_InitialEICounts
          [0];
        for (i1=0; i1 < 8; i1++) {
          dw_InitialEICounts[i1] = heli_q8_P.HILInitialize_EIInitial;
        }
      }

      result = hil_set_encoder_counts(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_EIChannels, 8U,
        &heli_q8_DW.HILInitialize_InitialEICounts[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }

    if ((heli_q8_P.HILInitialize_POPStart && !is_switching) ||
        (heli_q8_P.HILInitialize_POPEnter && is_switching)) {
      uint32_T num_duty_cycle_modes = 0;
      uint32_T num_frequency_modes = 0;

      {
        int_T i1;
        int32_T *dw_POModeValues = &heli_q8_DW.HILInitialize_POModeValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POModeValues[i1] = heli_q8_P.HILInitialize_POModes;
        }
      }

      result = hil_set_pwm_mode(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_POChannels, 8U, (t_pwm_mode *)
        &heli_q8_DW.HILInitialize_POModeValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }

      {
        int_T i1;
        const uint32_T *p_HILInitialize_POChannels =
          heli_q8_P.HILInitialize_POChannels;
        int32_T *dw_POModeValues = &heli_q8_DW.HILInitialize_POModeValues[0];
        for (i1=0; i1 < 8; i1++) {
          if (dw_POModeValues[i1] == PWM_DUTY_CYCLE_MODE || dw_POModeValues[i1] ==
              PWM_ONE_SHOT_MODE || dw_POModeValues[i1] == PWM_TIME_MODE ||
              dw_POModeValues[i1] == PWM_RAW_MODE) {
            heli_q8_DW.HILInitialize_POSortedChans[num_duty_cycle_modes] =
              (p_HILInitialize_POChannels[i1]);
            heli_q8_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes] =
              heli_q8_P.HILInitialize_POFrequency;
            num_duty_cycle_modes++;
          } else {
            heli_q8_DW.HILInitialize_POSortedChans[7U - num_frequency_modes] =
              (p_HILInitialize_POChannels[i1]);
            heli_q8_DW.HILInitialize_POSortedFreqs[7U - num_frequency_modes] =
              heli_q8_P.HILInitialize_POFrequency;
            num_frequency_modes++;
          }
        }
      }

      if (num_duty_cycle_modes > 0) {
        result = hil_set_pwm_frequency(heli_q8_DW.HILInitialize_Card,
          &heli_q8_DW.HILInitialize_POSortedChans[0], num_duty_cycle_modes,
          &heli_q8_DW.HILInitialize_POSortedFreqs[0]);
        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(heli_q8_M, _rt_error_message);
          return;
        }
      }

      if (num_frequency_modes > 0) {
        result = hil_set_pwm_duty_cycle(heli_q8_DW.HILInitialize_Card,
          &heli_q8_DW.HILInitialize_POSortedChans[num_duty_cycle_modes],
          num_frequency_modes,
          &heli_q8_DW.HILInitialize_POSortedFreqs[num_duty_cycle_modes]);
        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(heli_q8_M, _rt_error_message);
          return;
        }
      }

      {
        int_T i1;
        int32_T *dw_POModeValues = &heli_q8_DW.HILInitialize_POModeValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POModeValues[i1] = heli_q8_P.HILInitialize_POConfiguration;
        }
      }

      {
        int_T i1;
        int32_T *dw_POAlignValues = &heli_q8_DW.HILInitialize_POAlignValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POAlignValues[i1] = heli_q8_P.HILInitialize_POAlignment;
        }
      }

      {
        int_T i1;
        int32_T *dw_POPolarityVals = &heli_q8_DW.HILInitialize_POPolarityVals[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POPolarityVals[i1] = heli_q8_P.HILInitialize_POPolarity;
        }
      }

      result = hil_set_pwm_configuration(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_POChannels, 8U,
        (t_pwm_configuration *) &heli_q8_DW.HILInitialize_POModeValues[0],
        (t_pwm_alignment *) &heli_q8_DW.HILInitialize_POAlignValues[0],
        (t_pwm_polarity *) &heli_q8_DW.HILInitialize_POPolarityVals[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }

      {
        int_T i1;
        real_T *dw_POSortedFreqs = &heli_q8_DW.HILInitialize_POSortedFreqs[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POSortedFreqs[i1] = heli_q8_P.HILInitialize_POLeading;
        }
      }

      {
        int_T i1;
        real_T *dw_POValues = &heli_q8_DW.HILInitialize_POValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POValues[i1] = heli_q8_P.HILInitialize_POTrailing;
        }
      }

      result = hil_set_pwm_deadband(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_POChannels, 8U,
        &heli_q8_DW.HILInitialize_POSortedFreqs[0],
        &heli_q8_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }

    if ((heli_q8_P.HILInitialize_POStart && !is_switching) ||
        (heli_q8_P.HILInitialize_POEnter && is_switching)) {
      {
        int_T i1;
        real_T *dw_POValues = &heli_q8_DW.HILInitialize_POValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POValues[i1] = heli_q8_P.HILInitialize_POInitial;
        }
      }

      result = hil_write_pwm(heli_q8_DW.HILInitialize_Card,
        heli_q8_P.HILInitialize_POChannels, 8U,
        &heli_q8_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }

    if (heli_q8_P.HILInitialize_POReset) {
      {
        int_T i1;
        real_T *dw_POValues = &heli_q8_DW.HILInitialize_POValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POValues[i1] = heli_q8_P.HILInitialize_POWatchdog;
        }
      }

      result = hil_watchdog_set_pwm_expiration_state
        (heli_q8_DW.HILInitialize_Card, heli_q8_P.HILInitialize_POChannels, 8U,
         &heli_q8_DW.HILInitialize_POValues[0]);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        return;
      }
    }
  }

  /* Start for S-Function (hil_read_encoder_timebase_block): '<S3>/HIL Read Encoder Timebase' */

  /* S-Function Block: heli_q8/Heli 3D/HIL Read Encoder Timebase (hil_read_encoder_timebase_block) */
  {
    t_error result;
    result = hil_task_create_encoder_reader(heli_q8_DW.HILInitialize_Card,
      heli_q8_P.HILReadEncoderTimebase_SamplesI,
      heli_q8_P.HILReadEncoderTimebase_Channels, 3,
      &heli_q8_DW.HILReadEncoderTimebase_Task);
    if (result >= 0) {
      result = hil_task_set_buffer_overflow_mode
        (heli_q8_DW.HILReadEncoderTimebase_Task, (t_buffer_overflow_mode)
         (heli_q8_P.HILReadEncoderTimebase_Overflow - 1));
    }

    if (result < 0) {
      msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
        (_rt_error_message));
      rtmSetErrorStatus(heli_q8_M, _rt_error_message);
    }
  }

  /* Start for S-Function (stream_call_block): '<S11>/Stream Call2' incorporates:
   *  Constant: '<S11>/Constant4'
   *  S-Function (string_constant_block): '<S11>/String Constant1'
   */

  /* S-Function Block: heli_q8/IMU Block/IMU_BT/Stream Call2 (stream_call_block) */
  {
    heli_q8_DW.StreamCall2_State = STREAM_CALL_STATE_NOT_CONNECTED;
    heli_q8_DW.StreamCall2_Stream = NULL;
  }

  /* Start for RateTransition: '<S5>/Rate Transition: x' */
  heli_q8_B.RateTransitionx = heli_q8_P.RateTransitionx_InitialConditio;

  /* Start for RateTransition: '<S5>/Rate Transition: y' */
  heli_q8_B.RateTransitiony = heli_q8_P.RateTransitiony_InitialConditio;

  /* Start for ToFile: '<Root>/To File' */
  {
    FILE *fp = (NULL);
    char fileName[509] = "IMU09.mat";
    if ((fp = fopen(fileName, "wb")) == (NULL)) {
      rtmSetErrorStatus(heli_q8_M, "Error creating .mat file IMU09.mat");
      return;
    }

    if (rt_WriteMat4FileHeader(fp, 20 + 1, 0, "ans")) {
      rtmSetErrorStatus(heli_q8_M,
                        "Error writing mat file header to file IMU09.mat");
      return;
    }

    heli_q8_DW.ToFile_IWORK.Count = 0;
    heli_q8_DW.ToFile_IWORK.Decimation = -1;
    heli_q8_DW.ToFile_PWORK.FilePtr = fp;
  }

  /* Start for ToFile: '<S2>/To File1' */
  {
    FILE *fp = (NULL);
    char fileName[509] = "KalTest08.mat";
    if ((fp = fopen(fileName, "wb")) == (NULL)) {
      rtmSetErrorStatus(heli_q8_M, "Error creating .mat file KalTest08.mat");
      return;
    }

    if (rt_WriteMat4FileHeader(fp, 29 + 1, 0, "ans")) {
      rtmSetErrorStatus(heli_q8_M,
                        "Error writing mat file header to file KalTest08.mat");
      return;
    }

    heli_q8_DW.ToFile1_IWORK.Count = 0;
    heli_q8_DW.ToFile1_IWORK.Decimation = -1;
    heli_q8_DW.ToFile1_PWORK.FilePtr = fp;
  }

  /* Start for S-Function (game_controller_block): '<S5>/Game Controller' */

  /* S-Function Block: heli_q8/Joystick/Game Controller (game_controller_block) */
  {
    if (heli_q8_P.GameController_Enabled) {
      t_double deadzone[6];
      t_double saturation[6];
      t_int index;
      t_error result;
      for (index = 0; index < 6; index++) {
        deadzone[index] = -1;
      }

      for (index = 0; index < 6; index++) {
        saturation[index] = -1;
      }

      result = game_controller_open(heli_q8_P.GameController_ControllerNumber,
        heli_q8_P.GameController_BufferSize, deadzone, saturation,
        heli_q8_P.GameController_AutoCenter, 0, 1.0,
        &heli_q8_DW.GameController_Controller);
      if (result < 0) {
        msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
          (_rt_error_message));
        rtmSetErrorStatus(heli_q8_M, _rt_error_message);
      }
    }
  }

  {
    int32_T i;

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
    for (i = 0; i < 6; i++) {
      heli_q8_DW.UnitDelay_DSTATE[i] = heli_q8_P.x_bar_0[i];
    }

    /* End of InitializeConditions for UnitDelay: '<S2>/Unit Delay' */

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay1' */
    memcpy(&heli_q8_DW.UnitDelay1_DSTATE[0], &heli_q8_P.P_bar_0[0], 36U * sizeof
           (real_T));

    /* InitializeConditions for UnitDelay: '<S13>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_i = heli_q8_P.UnitDelay_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S14>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_o = heli_q8_P.UnitDelay_InitialCondition_b;

    /* InitializeConditions for UnitDelay: '<S15>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_od = heli_q8_P.UnitDelay_InitialCondition_j;

    /* InitializeConditions for UnitDelay: '<S16>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_l = heli_q8_P.UnitDelay_InitialCondition_k;

    /* InitializeConditions for UnitDelay: '<S17>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_e = heli_q8_P.UnitDelay_InitialCondition_h;

    /* InitializeConditions for UnitDelay: '<S18>/Unit Delay' */
    heli_q8_DW.UnitDelay_DSTATE_ei = heli_q8_P.UnitDelay_InitialCondition_g;

    /* InitializeConditions for TransferFcn: '<S3>/Pitch: Transfer Fcn' */
    heli_q8_X.PitchTransferFcn_CSTATE = 0.0;

    /* InitializeConditions for TransferFcn: '<S3>/Elevation: Transfer Fcn' */
    heli_q8_X.ElevationTransferFcn_CSTATE = 0.0;

    /* InitializeConditions for TransferFcn: '<S3>/Travel: Transfer Fcn' */
    heli_q8_X.TravelTransferFcn_CSTATE = 0.0;

    /* InitializeConditions for RateTransition: '<S5>/Rate Transition: x' */
    heli_q8_DW.RateTransitionx_Buffer0 =
      heli_q8_P.RateTransitionx_InitialConditio;

    /* InitializeConditions for RateTransition: '<S5>/Rate Transition: y' */
    heli_q8_DW.RateTransitiony_Buffer0 =
      heli_q8_P.RateTransitiony_InitialConditio;

    /* InitializeConditions for Integrator: '<S6>/Integrator' */
    heli_q8_X.Integrator_CSTATE = heli_q8_P.Integrator_IC;

    /* InitializeConditions for Integrator: '<S6>/Integrator1' */
    heli_q8_X.Integrator1_CSTATE = heli_q8_P.Integrator1_IC;
  }
}

/* Model terminate function */
void heli_q8_terminate(void)
{
  /* Terminate for S-Function (hil_initialize_block): '<Root>/HIL Initialize' */

  /* S-Function Block: heli_q8/HIL Initialize (hil_initialize_block) */
  {
    t_boolean is_switching;
    t_int result;
    t_uint32 num_final_analog_outputs = 0;
    t_uint32 num_final_pwm_outputs = 0;
    hil_task_stop_all(heli_q8_DW.HILInitialize_Card);
    hil_monitor_stop_all(heli_q8_DW.HILInitialize_Card);
    is_switching = false;
    if ((heli_q8_P.HILInitialize_AOTerminate && !is_switching) ||
        (heli_q8_P.HILInitialize_AOExit && is_switching)) {
      {
        int_T i1;
        real_T *dw_AOVoltages = &heli_q8_DW.HILInitialize_AOVoltages[0];
        for (i1=0; i1 < 8; i1++) {
          dw_AOVoltages[i1] = heli_q8_P.HILInitialize_AOFinal;
        }
      }

      num_final_analog_outputs = 8U;
    } else {
      num_final_analog_outputs = 0;
    }

    if ((heli_q8_P.HILInitialize_POTerminate && !is_switching) ||
        (heli_q8_P.HILInitialize_POExit && is_switching)) {
      {
        int_T i1;
        real_T *dw_POValues = &heli_q8_DW.HILInitialize_POValues[0];
        for (i1=0; i1 < 8; i1++) {
          dw_POValues[i1] = heli_q8_P.HILInitialize_POFinal;
        }
      }

      num_final_pwm_outputs = 8U;
    } else {
      num_final_pwm_outputs = 0;
    }

    if (0
        || num_final_analog_outputs > 0
        || num_final_pwm_outputs > 0
        ) {
      /* Attempt to write the final outputs atomically (due to firmware issue in old Q2-USB). Otherwise write channels individually */
      result = hil_write(heli_q8_DW.HILInitialize_Card
                         , heli_q8_P.HILInitialize_AOChannels,
                         num_final_analog_outputs
                         , heli_q8_P.HILInitialize_POChannels,
                         num_final_pwm_outputs
                         , NULL, 0
                         , NULL, 0
                         , &heli_q8_DW.HILInitialize_AOVoltages[0]
                         , &heli_q8_DW.HILInitialize_POValues[0]
                         , (t_boolean *) NULL
                         , NULL
                         );
      if (result == -QERR_HIL_WRITE_NOT_SUPPORTED) {
        t_error local_result;
        result = 0;

        /* The hil_write operation is not supported by this card. Write final outputs for each channel type */
        if (num_final_analog_outputs > 0) {
          local_result = hil_write_analog(heli_q8_DW.HILInitialize_Card,
            heli_q8_P.HILInitialize_AOChannels, num_final_analog_outputs,
            &heli_q8_DW.HILInitialize_AOVoltages[0]);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (num_final_pwm_outputs > 0) {
          local_result = hil_write_pwm(heli_q8_DW.HILInitialize_Card,
            heli_q8_P.HILInitialize_POChannels, num_final_pwm_outputs,
            &heli_q8_DW.HILInitialize_POValues[0]);
          if (local_result < 0) {
            result = local_result;
          }
        }

        if (result < 0) {
          msg_get_error_messageA(NULL, result, _rt_error_message, sizeof
            (_rt_error_message));
          rtmSetErrorStatus(heli_q8_M, _rt_error_message);
        }
      }
    }

    hil_task_delete_all(heli_q8_DW.HILInitialize_Card);
    hil_monitor_delete_all(heli_q8_DW.HILInitialize_Card);
    hil_close(heli_q8_DW.HILInitialize_Card);
    heli_q8_DW.HILInitialize_Card = NULL;
  }

  /* Terminate for S-Function (stream_call_block): '<S11>/Stream Call2' incorporates:
   *  Constant: '<S11>/Constant4'
   *  S-Function (string_constant_block): '<S11>/String Constant1'
   */

  /* S-Function Block: heli_q8/IMU Block/IMU_BT/Stream Call2 (stream_call_block) */
  {
    if (heli_q8_DW.StreamCall2_Stream != NULL) {
      stream_close(heli_q8_DW.StreamCall2_Stream);
      heli_q8_DW.StreamCall2_Stream = NULL;
    }
  }

  /* Terminate for ToFile: '<Root>/To File' */
  {
    FILE *fp = (FILE *) heli_q8_DW.ToFile_PWORK.FilePtr;
    if (fp != (NULL)) {
      char fileName[509] = "IMU09.mat";
      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(heli_q8_M, "Error closing MAT-file IMU09.mat");
        return;
      }

      if ((fp = fopen(fileName, "r+b")) == (NULL)) {
        rtmSetErrorStatus(heli_q8_M, "Error reopening MAT-file IMU09.mat");
        return;
      }

      if (rt_WriteMat4FileHeader(fp, 20 + 1, heli_q8_DW.ToFile_IWORK.Count,
           "ans")) {
        rtmSetErrorStatus(heli_q8_M,
                          "Error writing header for ans to MAT-file IMU09.mat");
      }

      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(heli_q8_M, "Error closing MAT-file IMU09.mat");
        return;
      }

      heli_q8_DW.ToFile_PWORK.FilePtr = (NULL);
    }
  }

  /* Terminate for ToFile: '<S2>/To File1' */
  {
    FILE *fp = (FILE *) heli_q8_DW.ToFile1_PWORK.FilePtr;
    if (fp != (NULL)) {
      char fileName[509] = "KalTest08.mat";
      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(heli_q8_M, "Error closing MAT-file KalTest08.mat");
        return;
      }

      if ((fp = fopen(fileName, "r+b")) == (NULL)) {
        rtmSetErrorStatus(heli_q8_M, "Error reopening MAT-file KalTest08.mat");
        return;
      }

      if (rt_WriteMat4FileHeader(fp, 29 + 1, heli_q8_DW.ToFile1_IWORK.Count,
           "ans")) {
        rtmSetErrorStatus(heli_q8_M,
                          "Error writing header for ans to MAT-file KalTest08.mat");
      }

      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(heli_q8_M, "Error closing MAT-file KalTest08.mat");
        return;
      }

      heli_q8_DW.ToFile1_PWORK.FilePtr = (NULL);
    }
  }

  /* Terminate for S-Function (game_controller_block): '<S5>/Game Controller' */

  /* S-Function Block: heli_q8/Joystick/Game Controller (game_controller_block) */
  {
    if (heli_q8_P.GameController_Enabled) {
      game_controller_close(heli_q8_DW.GameController_Controller);
      heli_q8_DW.GameController_Controller = NULL;
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  if (tid == 1)
    tid = 0;
  heli_q8_output(tid);
}

void MdlUpdate(int_T tid)
{
  if (tid == 1)
    tid = 0;
  heli_q8_update(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  heli_q8_initialize();
}

void MdlTerminate(void)
{
  heli_q8_terminate();
}

/* Registration function */
RT_MODEL_heli_q8_T *heli_q8(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  heli_q8_P.UnitDelay_InitialCondition = rtNaNF;
  heli_q8_P.UnitDelay_InitialCondition_b = rtNaNF;
  heli_q8_P.UnitDelay_InitialCondition_j = rtNaNF;
  heli_q8_P.UnitDelay_InitialCondition_k = rtNaNF;
  heli_q8_P.UnitDelay_InitialCondition_h = rtNaNF;
  heli_q8_P.UnitDelay_InitialCondition_g = rtNaNF;

  /* initialize real-time model */
  (void) memset((void *)heli_q8_M, 0,
                sizeof(RT_MODEL_heli_q8_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&heli_q8_M->solverInfo, &heli_q8_M->Timing.simTimeStep);
    rtsiSetTPtr(&heli_q8_M->solverInfo, &rtmGetTPtr(heli_q8_M));
    rtsiSetStepSizePtr(&heli_q8_M->solverInfo, &heli_q8_M->Timing.stepSize0);
    rtsiSetdXPtr(&heli_q8_M->solverInfo, &heli_q8_M->derivs);
    rtsiSetContStatesPtr(&heli_q8_M->solverInfo, (real_T **)
                         &heli_q8_M->contStates);
    rtsiSetNumContStatesPtr(&heli_q8_M->solverInfo,
      &heli_q8_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&heli_q8_M->solverInfo,
      &heli_q8_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&heli_q8_M->solverInfo,
      &heli_q8_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&heli_q8_M->solverInfo,
      &heli_q8_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&heli_q8_M->solverInfo, (&rtmGetErrorStatus(heli_q8_M)));
    rtsiSetRTModelPtr(&heli_q8_M->solverInfo, heli_q8_M);
  }

  rtsiSetSimTimeStep(&heli_q8_M->solverInfo, MAJOR_TIME_STEP);
  heli_q8_M->intgData.f[0] = heli_q8_M->odeF[0];
  heli_q8_M->contStates = ((real_T *) &heli_q8_X);
  rtsiSetSolverData(&heli_q8_M->solverInfo, (void *)&heli_q8_M->intgData);
  rtsiSetSolverName(&heli_q8_M->solverInfo,"ode1");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = heli_q8_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    mdlTsMap[2] = 2;
    heli_q8_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    heli_q8_M->Timing.sampleTimes = (&heli_q8_M->Timing.sampleTimesArray[0]);
    heli_q8_M->Timing.offsetTimes = (&heli_q8_M->Timing.offsetTimesArray[0]);

    /* task periods */
    heli_q8_M->Timing.sampleTimes[0] = (0.0);
    heli_q8_M->Timing.sampleTimes[1] = (0.002);
    heli_q8_M->Timing.sampleTimes[2] = (0.01);

    /* task offsets */
    heli_q8_M->Timing.offsetTimes[0] = (0.0);
    heli_q8_M->Timing.offsetTimes[1] = (0.0);
    heli_q8_M->Timing.offsetTimes[2] = (0.0);
  }

  rtmSetTPtr(heli_q8_M, &heli_q8_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = heli_q8_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits = heli_q8_M->Timing.perTaskSampleHitsArray;
    heli_q8_M->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    heli_q8_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(heli_q8_M, -1);
  heli_q8_M->Timing.stepSize0 = 0.002;
  heli_q8_M->Timing.stepSize1 = 0.002;
  heli_q8_M->Timing.stepSize2 = 0.01;

  /* External mode info */
  heli_q8_M->Sizes.checksums[0] = (1938405495U);
  heli_q8_M->Sizes.checksums[1] = (4227729713U);
  heli_q8_M->Sizes.checksums[2] = (881684195U);
  heli_q8_M->Sizes.checksums[3] = (1801499755U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[8];
    heli_q8_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = (sysRanDType *)&heli_q8_DW.Skiptonextline_SubsysRanBC;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(heli_q8_M->extModeInfo,
      &heli_q8_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(heli_q8_M->extModeInfo, heli_q8_M->Sizes.checksums);
    rteiSetTPtr(heli_q8_M->extModeInfo, rtmGetTPtr(heli_q8_M));
  }

  heli_q8_M->solverInfoPtr = (&heli_q8_M->solverInfo);
  heli_q8_M->Timing.stepSize = (0.002);
  rtsiSetFixedStepSize(&heli_q8_M->solverInfo, 0.002);
  rtsiSetSolverMode(&heli_q8_M->solverInfo, SOLVER_MODE_MULTITASKING);

  /* block I/O */
  heli_q8_M->blockIO = ((void *) &heli_q8_B);
  (void) memset(((void *) &heli_q8_B), 0,
                sizeof(B_heli_q8_T));

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      heli_q8_B.x_k[i] = 0.0;
    }

    for (i = 0; i < 36; i++) {
      heli_q8_B.P_k[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      heli_q8_B.x_bar_next[i] = 0.0;
    }

    for (i = 0; i < 36; i++) {
      heli_q8_B.P_bar_next[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      heli_q8_B.x_hat[i] = 0.0;
    }

    for (i = 0; i < 36; i++) {
      heli_q8_B.P_hat[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      heli_q8_B.P_cov_diag[i] = 0.0;
    }

    heli_q8_B.DataTypeConversion1[0] = 0.0;
    heli_q8_B.DataTypeConversion1[1] = 0.0;
    heli_q8_B.DataTypeConversion1[2] = 0.0;
    heli_q8_B.Gain2[0] = 0.0;
    heli_q8_B.Gain2[1] = 0.0;
    heli_q8_B.Gain2[2] = 0.0;
    heli_q8_B.DataTypeConversion2[0] = 0.0;
    heli_q8_B.DataTypeConversion2[1] = 0.0;
    heli_q8_B.DataTypeConversion2[2] = 0.0;
    heli_q8_B.Gain1[0] = 0.0;
    heli_q8_B.Gain1[1] = 0.0;
    heli_q8_B.Gain1[2] = 0.0;
    heli_q8_B.Sum7 = 0.0;
    heli_q8_B.Sum5 = 0.0;
    heli_q8_B.Sum2 = 0.0;
    heli_q8_B.ManualSwitch = 0.0;
    heli_q8_B.PitchCounttorad = 0.0;
    heli_q8_B.PitchTransferFcn = 0.0;
    heli_q8_B.ElevationCounttorad = 0.0;
    heli_q8_B.ElevationTransferFcn = 0.0;
    heli_q8_B.TravelCounttorad = 0.0;
    heli_q8_B.Innvertering2 = 0.0;
    heli_q8_B.Sum = 0.0;
    heli_q8_B.RateTransitionx = 0.0;
    heli_q8_B.Joystick_gain_x = 0.0;
    heli_q8_B.Sum_n = 0.0;
    heli_q8_B.RateTransitiony = 0.0;
    heli_q8_B.Joystick_gain_y = 0.0;
    heli_q8_B.e_c_dot = 0.0;
    heli_q8_B.u[0] = 0.0;
    heli_q8_B.u[1] = 0.0;
    heli_q8_B.V_s = 0.0;
    heli_q8_B.Innvertering = 0.0;
    heli_q8_B.FrontmotorSaturation = 0.0;
    heli_q8_B.BackmotorSaturation = 0.0;
    heli_q8_B.gamma_dot = 0.0;
    heli_q8_B.Zeta_dot = 0.0;
    heli_q8_B.pe[0] = 0.0;
    heli_q8_B.pe[1] = 0.0;
    heli_q8_B.StreamFormattedRead1_o2 = 0.0F;
    heli_q8_B.StreamFormattedRead1_o3 = 0.0F;
    heli_q8_B.StreamFormattedRead1_o4 = 0.0F;
    heli_q8_B.StreamFormattedRead1_o5 = 0.0F;
    heli_q8_B.StreamFormattedRead1_o6 = 0.0F;
    heli_q8_B.StreamFormattedRead1_o7 = 0.0F;
    heli_q8_B.UnitDelay = 0.0F;
    heli_q8_B.UnitDelay_d = 0.0F;
    heli_q8_B.UnitDelay_f = 0.0F;
    heli_q8_B.UnitDelay_m = 0.0F;
    heli_q8_B.UnitDelay_dq = 0.0F;
    heli_q8_B.UnitDelay_h = 0.0F;
  }

  /* parameters */
  heli_q8_M->defaultParam = ((real_T *)&heli_q8_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &heli_q8_X;
    heli_q8_M->contStates = (x);
    (void) memset((void *)&heli_q8_X, 0,
                  sizeof(X_heli_q8_T));
  }

  /* states (dwork) */
  heli_q8_M->dwork = ((void *) &heli_q8_DW);
  (void) memset((void *)&heli_q8_DW, 0,
                sizeof(DW_heli_q8_T));

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      heli_q8_DW.UnitDelay_DSTATE[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 36; i++) {
      heli_q8_DW.UnitDelay1_DSTATE[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      heli_q8_DW.HILInitialize_AIMinimums[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      heli_q8_DW.HILInitialize_AIMaximums[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      heli_q8_DW.HILInitialize_AOMinimums[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      heli_q8_DW.HILInitialize_AOMaximums[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      heli_q8_DW.HILInitialize_AOVoltages[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      heli_q8_DW.HILInitialize_FilterFrequency[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      heli_q8_DW.HILInitialize_POSortedFreqs[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      heli_q8_DW.HILInitialize_POValues[i] = 0.0;
    }
  }

  heli_q8_DW.RateTransitionx_Buffer0 = 0.0;
  heli_q8_DW.RateTransitiony_Buffer0 = 0.0;
  heli_q8_DW.HILWriteAnalog_Buffer[0] = 0.0;
  heli_q8_DW.HILWriteAnalog_Buffer[1] = 0.0;
  heli_q8_DW.UnitDelay_DSTATE_i = 0.0F;
  heli_q8_DW.UnitDelay_DSTATE_o = 0.0F;
  heli_q8_DW.UnitDelay_DSTATE_od = 0.0F;
  heli_q8_DW.UnitDelay_DSTATE_l = 0.0F;
  heli_q8_DW.UnitDelay_DSTATE_e = 0.0F;
  heli_q8_DW.UnitDelay_DSTATE_ei = 0.0F;

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    heli_q8_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 25;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  heli_q8_M->Sizes.numContStates = (5);/* Number of continuous states */
  heli_q8_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  heli_q8_M->Sizes.numY = (0);         /* Number of model outputs */
  heli_q8_M->Sizes.numU = (0);         /* Number of model inputs */
  heli_q8_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  heli_q8_M->Sizes.numSampTimes = (3); /* Number of sample times */
  heli_q8_M->Sizes.numBlocks = (128);  /* Number of blocks */
  heli_q8_M->Sizes.numBlockIO = (57);  /* Number of block outputs */
  heli_q8_M->Sizes.numBlockPrms = (635);/* Sum of parameter "widths" */
  return heli_q8_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
