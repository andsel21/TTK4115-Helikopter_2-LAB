  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 9;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (heli_q8_P)
    ;%
      section.nData     = 12;
      section.data(12)  = dumData; %prealloc
      
	  ;% heli_q8_P.A_d
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_P.B_d
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 36;
	
	  ;% heli_q8_P.C_d
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 48;
	
	  ;% heli_q8_P.F
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 78;
	
	  ;% heli_q8_P.Joystick_gain_x
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 82;
	
	  ;% heli_q8_P.Joystick_gain_y
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 83;
	
	  ;% heli_q8_P.K
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 84;
	
	  ;% heli_q8_P.P_bar_0
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 94;
	
	  ;% heli_q8_P.Q_d
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 130;
	
	  ;% heli_q8_P.R_d
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 166;
	
	  ;% heli_q8_P.v_s0
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 191;
	
	  ;% heli_q8_P.x_bar_0
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 192;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_P.HILWriteAnalog_channels
	  section.data(1).logicalSrcIdx = 12;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(2) = section;
      clear section
      
      section.nData     = 60;
      section.data(60)  = dumData; %prealloc
      
	  ;% heli_q8_P.Constant_Value
	  section.data(1).logicalSrcIdx = 13;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_P.HILInitialize_OOTerminate
	  section.data(2).logicalSrcIdx = 14;
	  section.data(2).dtTransOffset = 1;
	
	  ;% heli_q8_P.HILInitialize_OOExit
	  section.data(3).logicalSrcIdx = 15;
	  section.data(3).dtTransOffset = 2;
	
	  ;% heli_q8_P.HILInitialize_OOStart
	  section.data(4).logicalSrcIdx = 16;
	  section.data(4).dtTransOffset = 3;
	
	  ;% heli_q8_P.HILInitialize_OOEnter
	  section.data(5).logicalSrcIdx = 17;
	  section.data(5).dtTransOffset = 4;
	
	  ;% heli_q8_P.HILInitialize_AOFinal
	  section.data(6).logicalSrcIdx = 18;
	  section.data(6).dtTransOffset = 5;
	
	  ;% heli_q8_P.HILInitialize_POFinal
	  section.data(7).logicalSrcIdx = 19;
	  section.data(7).dtTransOffset = 6;
	
	  ;% heli_q8_P.HILInitialize_AIHigh
	  section.data(8).logicalSrcIdx = 20;
	  section.data(8).dtTransOffset = 7;
	
	  ;% heli_q8_P.HILInitialize_AILow
	  section.data(9).logicalSrcIdx = 21;
	  section.data(9).dtTransOffset = 8;
	
	  ;% heli_q8_P.HILInitialize_AOHigh
	  section.data(10).logicalSrcIdx = 22;
	  section.data(10).dtTransOffset = 9;
	
	  ;% heli_q8_P.HILInitialize_AOLow
	  section.data(11).logicalSrcIdx = 23;
	  section.data(11).dtTransOffset = 10;
	
	  ;% heli_q8_P.HILInitialize_AOInitial
	  section.data(12).logicalSrcIdx = 24;
	  section.data(12).dtTransOffset = 11;
	
	  ;% heli_q8_P.HILInitialize_AOWatchdog
	  section.data(13).logicalSrcIdx = 25;
	  section.data(13).dtTransOffset = 12;
	
	  ;% heli_q8_P.HILInitialize_POFrequency
	  section.data(14).logicalSrcIdx = 26;
	  section.data(14).dtTransOffset = 13;
	
	  ;% heli_q8_P.HILInitialize_POLeading
	  section.data(15).logicalSrcIdx = 27;
	  section.data(15).dtTransOffset = 14;
	
	  ;% heli_q8_P.HILInitialize_POTrailing
	  section.data(16).logicalSrcIdx = 28;
	  section.data(16).dtTransOffset = 15;
	
	  ;% heli_q8_P.HILInitialize_POInitial
	  section.data(17).logicalSrcIdx = 29;
	  section.data(17).dtTransOffset = 16;
	
	  ;% heli_q8_P.HILInitialize_POWatchdog
	  section.data(18).logicalSrcIdx = 30;
	  section.data(18).dtTransOffset = 17;
	
	  ;% heli_q8_P.Constant4_Value
	  section.data(19).logicalSrcIdx = 31;
	  section.data(19).dtTransOffset = 18;
	
	  ;% heli_q8_P.Gain2_Gain
	  section.data(20).logicalSrcIdx = 32;
	  section.data(20).dtTransOffset = 19;
	
	  ;% heli_q8_P.Gain1_Gain
	  section.data(21).logicalSrcIdx = 33;
	  section.data(21).dtTransOffset = 28;
	
	  ;% heli_q8_P.Constant4_Value_p
	  section.data(22).logicalSrcIdx = 34;
	  section.data(22).dtTransOffset = 37;
	
	  ;% heli_q8_P.Constant1_Value
	  section.data(23).logicalSrcIdx = 35;
	  section.data(23).dtTransOffset = 38;
	
	  ;% heli_q8_P.Constant_Value_c
	  section.data(24).logicalSrcIdx = 36;
	  section.data(24).dtTransOffset = 39;
	
	  ;% heli_q8_P.PitchCounttorad_Gain
	  section.data(25).logicalSrcIdx = 37;
	  section.data(25).dtTransOffset = 40;
	
	  ;% heli_q8_P.PitchTransferFcn_A
	  section.data(26).logicalSrcIdx = 38;
	  section.data(26).dtTransOffset = 41;
	
	  ;% heli_q8_P.PitchTransferFcn_C
	  section.data(27).logicalSrcIdx = 39;
	  section.data(27).dtTransOffset = 42;
	
	  ;% heli_q8_P.PitchTransferFcn_D
	  section.data(28).logicalSrcIdx = 40;
	  section.data(28).dtTransOffset = 43;
	
	  ;% heli_q8_P.ElevationCounttorad_Gain
	  section.data(29).logicalSrcIdx = 41;
	  section.data(29).dtTransOffset = 44;
	
	  ;% heli_q8_P.ElevationTransferFcn_A
	  section.data(30).logicalSrcIdx = 42;
	  section.data(30).dtTransOffset = 45;
	
	  ;% heli_q8_P.ElevationTransferFcn_C
	  section.data(31).logicalSrcIdx = 43;
	  section.data(31).dtTransOffset = 46;
	
	  ;% heli_q8_P.ElevationTransferFcn_D
	  section.data(32).logicalSrcIdx = 44;
	  section.data(32).dtTransOffset = 47;
	
	  ;% heli_q8_P.TravelCounttorad_Gain
	  section.data(33).logicalSrcIdx = 45;
	  section.data(33).dtTransOffset = 48;
	
	  ;% heli_q8_P.TravelTransferFcn_A
	  section.data(34).logicalSrcIdx = 46;
	  section.data(34).dtTransOffset = 49;
	
	  ;% heli_q8_P.TravelTransferFcn_C
	  section.data(35).logicalSrcIdx = 47;
	  section.data(35).dtTransOffset = 50;
	
	  ;% heli_q8_P.TravelTransferFcn_D
	  section.data(36).logicalSrcIdx = 48;
	  section.data(36).dtTransOffset = 51;
	
	  ;% heli_q8_P.Innvertering2_Gain
	  section.data(37).logicalSrcIdx = 49;
	  section.data(37).dtTransOffset = 52;
	
	  ;% heli_q8_P.Constant_Elevation_Value
	  section.data(38).logicalSrcIdx = 50;
	  section.data(38).dtTransOffset = 53;
	
	  ;% heli_q8_P.Step_Time
	  section.data(39).logicalSrcIdx = 51;
	  section.data(39).dtTransOffset = 54;
	
	  ;% heli_q8_P.Step_Y0
	  section.data(40).logicalSrcIdx = 52;
	  section.data(40).dtTransOffset = 55;
	
	  ;% heli_q8_P.Step_YFinal
	  section.data(41).logicalSrcIdx = 53;
	  section.data(41).dtTransOffset = 56;
	
	  ;% heli_q8_P.RateTransitionx_InitialConditio
	  section.data(42).logicalSrcIdx = 54;
	  section.data(42).dtTransOffset = 57;
	
	  ;% heli_q8_P.DeadZonex_Start
	  section.data(43).logicalSrcIdx = 55;
	  section.data(43).dtTransOffset = 58;
	
	  ;% heli_q8_P.DeadZonex_End
	  section.data(44).logicalSrcIdx = 56;
	  section.data(44).dtTransOffset = 59;
	
	  ;% heli_q8_P.Gainx_Gain
	  section.data(45).logicalSrcIdx = 57;
	  section.data(45).dtTransOffset = 60;
	
	  ;% heli_q8_P.Gain_Gain
	  section.data(46).logicalSrcIdx = 58;
	  section.data(46).dtTransOffset = 61;
	
	  ;% heli_q8_P.RateTransitiony_InitialConditio
	  section.data(47).logicalSrcIdx = 59;
	  section.data(47).dtTransOffset = 62;
	
	  ;% heli_q8_P.DeadZoney_Start
	  section.data(48).logicalSrcIdx = 60;
	  section.data(48).dtTransOffset = 63;
	
	  ;% heli_q8_P.DeadZoney_End
	  section.data(49).logicalSrcIdx = 61;
	  section.data(49).dtTransOffset = 64;
	
	  ;% heli_q8_P.Gainy_Gain
	  section.data(50).logicalSrcIdx = 62;
	  section.data(50).dtTransOffset = 65;
	
	  ;% heli_q8_P.Gain1_Gain_b
	  section.data(51).logicalSrcIdx = 63;
	  section.data(51).dtTransOffset = 66;
	
	  ;% heli_q8_P.Integrator_IC
	  section.data(52).logicalSrcIdx = 64;
	  section.data(52).dtTransOffset = 67;
	
	  ;% heli_q8_P.Integrator1_IC
	  section.data(53).logicalSrcIdx = 65;
	  section.data(53).dtTransOffset = 68;
	
	  ;% heli_q8_P.Innvertering_Gain
	  section.data(54).logicalSrcIdx = 66;
	  section.data(54).dtTransOffset = 69;
	
	  ;% heli_q8_P.Backgain_Gain
	  section.data(55).logicalSrcIdx = 67;
	  section.data(55).dtTransOffset = 70;
	
	  ;% heli_q8_P.Frontgain_Gain
	  section.data(56).logicalSrcIdx = 68;
	  section.data(56).dtTransOffset = 71;
	
	  ;% heli_q8_P.FrontmotorSaturation_UpperSat
	  section.data(57).logicalSrcIdx = 69;
	  section.data(57).dtTransOffset = 72;
	
	  ;% heli_q8_P.FrontmotorSaturation_LowerSat
	  section.data(58).logicalSrcIdx = 70;
	  section.data(58).dtTransOffset = 73;
	
	  ;% heli_q8_P.BackmotorSaturation_UpperSat
	  section.data(59).logicalSrcIdx = 71;
	  section.data(59).dtTransOffset = 74;
	
	  ;% heli_q8_P.BackmotorSaturation_LowerSat
	  section.data(60).logicalSrcIdx = 72;
	  section.data(60).dtTransOffset = 75;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(3) = section;
      clear section
      
      section.nData     = 10;
      section.data(10)  = dumData; %prealloc
      
	  ;% heli_q8_P.HILInitialize_CKChannels
	  section.data(1).logicalSrcIdx = 73;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_P.HILInitialize_DOWatchdog
	  section.data(2).logicalSrcIdx = 74;
	  section.data(2).dtTransOffset = 3;
	
	  ;% heli_q8_P.HILInitialize_EIInitial
	  section.data(3).logicalSrcIdx = 75;
	  section.data(3).dtTransOffset = 4;
	
	  ;% heli_q8_P.HILInitialize_POModes
	  section.data(4).logicalSrcIdx = 76;
	  section.data(4).dtTransOffset = 5;
	
	  ;% heli_q8_P.HILInitialize_POConfiguration
	  section.data(5).logicalSrcIdx = 77;
	  section.data(5).dtTransOffset = 6;
	
	  ;% heli_q8_P.HILInitialize_POAlignment
	  section.data(6).logicalSrcIdx = 78;
	  section.data(6).dtTransOffset = 7;
	
	  ;% heli_q8_P.HILInitialize_POPolarity
	  section.data(7).logicalSrcIdx = 79;
	  section.data(7).dtTransOffset = 8;
	
	  ;% heli_q8_P.HILReadEncoderTimebase_Clock
	  section.data(8).logicalSrcIdx = 80;
	  section.data(8).dtTransOffset = 9;
	
	  ;% heli_q8_P.StreamCall2_SendBufferSize
	  section.data(9).logicalSrcIdx = 81;
	  section.data(9).dtTransOffset = 10;
	
	  ;% heli_q8_P.StreamCall2_ReceiveBufferSize
	  section.data(10).logicalSrcIdx = 82;
	  section.data(10).dtTransOffset = 11;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(4) = section;
      clear section
      
      section.nData     = 6;
      section.data(6)  = dumData; %prealloc
      
	  ;% heli_q8_P.UnitDelay_InitialCondition
	  section.data(1).logicalSrcIdx = 83;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_P.UnitDelay_InitialCondition_b
	  section.data(2).logicalSrcIdx = 84;
	  section.data(2).dtTransOffset = 1;
	
	  ;% heli_q8_P.UnitDelay_InitialCondition_j
	  section.data(3).logicalSrcIdx = 85;
	  section.data(3).dtTransOffset = 2;
	
	  ;% heli_q8_P.UnitDelay_InitialCondition_k
	  section.data(4).logicalSrcIdx = 86;
	  section.data(4).dtTransOffset = 3;
	
	  ;% heli_q8_P.UnitDelay_InitialCondition_h
	  section.data(5).logicalSrcIdx = 87;
	  section.data(5).dtTransOffset = 4;
	
	  ;% heli_q8_P.UnitDelay_InitialCondition_g
	  section.data(6).logicalSrcIdx = 88;
	  section.data(6).dtTransOffset = 5;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(5) = section;
      clear section
      
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% heli_q8_P.StreamFormattedRead_MaxUnits
	  section.data(1).logicalSrcIdx = 89;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_P.HILInitialize_AIChannels
	  section.data(2).logicalSrcIdx = 90;
	  section.data(2).dtTransOffset = 1;
	
	  ;% heli_q8_P.HILInitialize_AOChannels
	  section.data(3).logicalSrcIdx = 91;
	  section.data(3).dtTransOffset = 9;
	
	  ;% heli_q8_P.HILInitialize_EIChannels
	  section.data(4).logicalSrcIdx = 92;
	  section.data(4).dtTransOffset = 17;
	
	  ;% heli_q8_P.HILInitialize_EIQuadrature
	  section.data(5).logicalSrcIdx = 93;
	  section.data(5).dtTransOffset = 25;
	
	  ;% heli_q8_P.HILInitialize_POChannels
	  section.data(6).logicalSrcIdx = 94;
	  section.data(6).dtTransOffset = 26;
	
	  ;% heli_q8_P.HILReadEncoderTimebase_Channels
	  section.data(7).logicalSrcIdx = 95;
	  section.data(7).dtTransOffset = 34;
	
	  ;% heli_q8_P.HILReadEncoderTimebase_SamplesI
	  section.data(8).logicalSrcIdx = 96;
	  section.data(8).dtTransOffset = 37;
	
	  ;% heli_q8_P.StreamFormattedRead1_MaxUnits
	  section.data(9).logicalSrcIdx = 97;
	  section.data(9).dtTransOffset = 38;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(6) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_P.GameController_BufferSize
	  section.data(1).logicalSrcIdx = 98;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(7) = section;
      clear section
      
      section.nData     = 41;
      section.data(41)  = dumData; %prealloc
      
	  ;% heli_q8_P.HILInitialize_Active
	  section.data(1).logicalSrcIdx = 99;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_P.HILInitialize_AOTerminate
	  section.data(2).logicalSrcIdx = 100;
	  section.data(2).dtTransOffset = 1;
	
	  ;% heli_q8_P.HILInitialize_AOExit
	  section.data(3).logicalSrcIdx = 101;
	  section.data(3).dtTransOffset = 2;
	
	  ;% heli_q8_P.HILInitialize_DOTerminate
	  section.data(4).logicalSrcIdx = 102;
	  section.data(4).dtTransOffset = 3;
	
	  ;% heli_q8_P.HILInitialize_DOExit
	  section.data(5).logicalSrcIdx = 103;
	  section.data(5).dtTransOffset = 4;
	
	  ;% heli_q8_P.HILInitialize_POTerminate
	  section.data(6).logicalSrcIdx = 104;
	  section.data(6).dtTransOffset = 5;
	
	  ;% heli_q8_P.HILInitialize_POExit
	  section.data(7).logicalSrcIdx = 105;
	  section.data(7).dtTransOffset = 6;
	
	  ;% heli_q8_P.HILInitialize_CKPStart
	  section.data(8).logicalSrcIdx = 106;
	  section.data(8).dtTransOffset = 7;
	
	  ;% heli_q8_P.HILInitialize_CKPEnter
	  section.data(9).logicalSrcIdx = 107;
	  section.data(9).dtTransOffset = 8;
	
	  ;% heli_q8_P.HILInitialize_CKStart
	  section.data(10).logicalSrcIdx = 108;
	  section.data(10).dtTransOffset = 9;
	
	  ;% heli_q8_P.HILInitialize_CKEnter
	  section.data(11).logicalSrcIdx = 109;
	  section.data(11).dtTransOffset = 10;
	
	  ;% heli_q8_P.HILInitialize_AIPStart
	  section.data(12).logicalSrcIdx = 110;
	  section.data(12).dtTransOffset = 11;
	
	  ;% heli_q8_P.HILInitialize_AIPEnter
	  section.data(13).logicalSrcIdx = 111;
	  section.data(13).dtTransOffset = 12;
	
	  ;% heli_q8_P.HILInitialize_AOPStart
	  section.data(14).logicalSrcIdx = 112;
	  section.data(14).dtTransOffset = 13;
	
	  ;% heli_q8_P.HILInitialize_AOPEnter
	  section.data(15).logicalSrcIdx = 113;
	  section.data(15).dtTransOffset = 14;
	
	  ;% heli_q8_P.HILInitialize_AOStart
	  section.data(16).logicalSrcIdx = 114;
	  section.data(16).dtTransOffset = 15;
	
	  ;% heli_q8_P.HILInitialize_AOEnter
	  section.data(17).logicalSrcIdx = 115;
	  section.data(17).dtTransOffset = 16;
	
	  ;% heli_q8_P.HILInitialize_AOReset
	  section.data(18).logicalSrcIdx = 116;
	  section.data(18).dtTransOffset = 17;
	
	  ;% heli_q8_P.HILInitialize_DOPStart
	  section.data(19).logicalSrcIdx = 117;
	  section.data(19).dtTransOffset = 18;
	
	  ;% heli_q8_P.HILInitialize_DOPEnter
	  section.data(20).logicalSrcIdx = 118;
	  section.data(20).dtTransOffset = 19;
	
	  ;% heli_q8_P.HILInitialize_DOStart
	  section.data(21).logicalSrcIdx = 119;
	  section.data(21).dtTransOffset = 20;
	
	  ;% heli_q8_P.HILInitialize_DOEnter
	  section.data(22).logicalSrcIdx = 120;
	  section.data(22).dtTransOffset = 21;
	
	  ;% heli_q8_P.HILInitialize_DOReset
	  section.data(23).logicalSrcIdx = 121;
	  section.data(23).dtTransOffset = 22;
	
	  ;% heli_q8_P.HILInitialize_EIPStart
	  section.data(24).logicalSrcIdx = 122;
	  section.data(24).dtTransOffset = 23;
	
	  ;% heli_q8_P.HILInitialize_EIPEnter
	  section.data(25).logicalSrcIdx = 123;
	  section.data(25).dtTransOffset = 24;
	
	  ;% heli_q8_P.HILInitialize_EIStart
	  section.data(26).logicalSrcIdx = 124;
	  section.data(26).dtTransOffset = 25;
	
	  ;% heli_q8_P.HILInitialize_EIEnter
	  section.data(27).logicalSrcIdx = 125;
	  section.data(27).dtTransOffset = 26;
	
	  ;% heli_q8_P.HILInitialize_POPStart
	  section.data(28).logicalSrcIdx = 126;
	  section.data(28).dtTransOffset = 27;
	
	  ;% heli_q8_P.HILInitialize_POPEnter
	  section.data(29).logicalSrcIdx = 127;
	  section.data(29).dtTransOffset = 28;
	
	  ;% heli_q8_P.HILInitialize_POStart
	  section.data(30).logicalSrcIdx = 128;
	  section.data(30).dtTransOffset = 29;
	
	  ;% heli_q8_P.HILInitialize_POEnter
	  section.data(31).logicalSrcIdx = 129;
	  section.data(31).dtTransOffset = 30;
	
	  ;% heli_q8_P.HILInitialize_POReset
	  section.data(32).logicalSrcIdx = 130;
	  section.data(32).dtTransOffset = 31;
	
	  ;% heli_q8_P.HILInitialize_OOReset
	  section.data(33).logicalSrcIdx = 131;
	  section.data(33).dtTransOffset = 32;
	
	  ;% heli_q8_P.HILInitialize_DOFinal
	  section.data(34).logicalSrcIdx = 132;
	  section.data(34).dtTransOffset = 33;
	
	  ;% heli_q8_P.HILInitialize_DOInitial
	  section.data(35).logicalSrcIdx = 133;
	  section.data(35).dtTransOffset = 34;
	
	  ;% heli_q8_P.HILReadEncoderTimebase_Active
	  section.data(36).logicalSrcIdx = 134;
	  section.data(36).dtTransOffset = 35;
	
	  ;% heli_q8_P.StreamCall2_NonBlocking
	  section.data(37).logicalSrcIdx = 135;
	  section.data(37).dtTransOffset = 36;
	
	  ;% heli_q8_P.StreamCall2_Active
	  section.data(38).logicalSrcIdx = 136;
	  section.data(38).dtTransOffset = 37;
	
	  ;% heli_q8_P.HILWriteAnalog_Active
	  section.data(39).logicalSrcIdx = 137;
	  section.data(39).dtTransOffset = 38;
	
	  ;% heli_q8_P.GameController_AutoCenter
	  section.data(40).logicalSrcIdx = 138;
	  section.data(40).dtTransOffset = 39;
	
	  ;% heli_q8_P.GameController_Enabled
	  section.data(41).logicalSrcIdx = 139;
	  section.data(41).dtTransOffset = 40;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(8) = section;
      clear section
      
      section.nData     = 6;
      section.data(6)  = dumData; %prealloc
      
	  ;% heli_q8_P.HILReadEncoderTimebase_Overflow
	  section.data(1).logicalSrcIdx = 140;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_P.StringConstant1_Value
	  section.data(2).logicalSrcIdx = 141;
	  section.data(2).dtTransOffset = 1;
	
	  ;% heli_q8_P.StreamCall2_URI
	  section.data(3).logicalSrcIdx = 142;
	  section.data(3).dtTransOffset = 256;
	
	  ;% heli_q8_P.StreamCall2_Endian
	  section.data(4).logicalSrcIdx = 143;
	  section.data(4).dtTransOffset = 257;
	
	  ;% heli_q8_P.ManualSwitch_CurrentSetting
	  section.data(5).logicalSrcIdx = 144;
	  section.data(5).dtTransOffset = 258;
	
	  ;% heli_q8_P.GameController_ControllerNumber
	  section.data(6).logicalSrcIdx = 145;
	  section.data(6).dtTransOffset = 259;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(9) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 4;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (heli_q8_B)
    ;%
      section.nData     = 36;
      section.data(36)  = dumData; %prealloc
      
	  ;% heli_q8_B.x_k
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_B.P_k
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 6;
	
	  ;% heli_q8_B.DataTypeConversion1
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 42;
	
	  ;% heli_q8_B.Gain2
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 45;
	
	  ;% heli_q8_B.DataTypeConversion2
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 48;
	
	  ;% heli_q8_B.Gain1
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 51;
	
	  ;% heli_q8_B.Sum7
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 54;
	
	  ;% heli_q8_B.Sum5
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 55;
	
	  ;% heli_q8_B.Sum2
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 56;
	
	  ;% heli_q8_B.ManualSwitch
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 57;
	
	  ;% heli_q8_B.PitchCounttorad
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 58;
	
	  ;% heli_q8_B.PitchTransferFcn
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 59;
	
	  ;% heli_q8_B.ElevationCounttorad
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 60;
	
	  ;% heli_q8_B.ElevationTransferFcn
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 61;
	
	  ;% heli_q8_B.TravelCounttorad
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 62;
	
	  ;% heli_q8_B.Innvertering2
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 63;
	
	  ;% heli_q8_B.Sum
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 64;
	
	  ;% heli_q8_B.RateTransitionx
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 65;
	
	  ;% heli_q8_B.Joystick_gain_x
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 66;
	
	  ;% heli_q8_B.Sum_n
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 67;
	
	  ;% heli_q8_B.RateTransitiony
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 68;
	
	  ;% heli_q8_B.Joystick_gain_y
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 69;
	
	  ;% heli_q8_B.e_c_dot
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 70;
	
	  ;% heli_q8_B.u
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 71;
	
	  ;% heli_q8_B.V_s
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 73;
	
	  ;% heli_q8_B.Innvertering
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 74;
	
	  ;% heli_q8_B.FrontmotorSaturation
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 75;
	
	  ;% heli_q8_B.BackmotorSaturation
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 76;
	
	  ;% heli_q8_B.gamma_dot
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 77;
	
	  ;% heli_q8_B.Zeta_dot
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 78;
	
	  ;% heli_q8_B.pe
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 79;
	
	  ;% heli_q8_B.x_bar_next
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 81;
	
	  ;% heli_q8_B.P_bar_next
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 87;
	
	  ;% heli_q8_B.x_hat
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 123;
	
	  ;% heli_q8_B.P_hat
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 129;
	
	  ;% heli_q8_B.P_cov_diag
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 165;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 12;
      section.data(12)  = dumData; %prealloc
      
	  ;% heli_q8_B.StreamFormattedRead1_o2
	  section.data(1).logicalSrcIdx = 36;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_B.StreamFormattedRead1_o3
	  section.data(2).logicalSrcIdx = 37;
	  section.data(2).dtTransOffset = 1;
	
	  ;% heli_q8_B.StreamFormattedRead1_o4
	  section.data(3).logicalSrcIdx = 38;
	  section.data(3).dtTransOffset = 2;
	
	  ;% heli_q8_B.StreamFormattedRead1_o5
	  section.data(4).logicalSrcIdx = 39;
	  section.data(4).dtTransOffset = 3;
	
	  ;% heli_q8_B.StreamFormattedRead1_o6
	  section.data(5).logicalSrcIdx = 40;
	  section.data(5).dtTransOffset = 4;
	
	  ;% heli_q8_B.StreamFormattedRead1_o7
	  section.data(6).logicalSrcIdx = 41;
	  section.data(6).dtTransOffset = 5;
	
	  ;% heli_q8_B.UnitDelay
	  section.data(7).logicalSrcIdx = 42;
	  section.data(7).dtTransOffset = 6;
	
	  ;% heli_q8_B.UnitDelay_d
	  section.data(8).logicalSrcIdx = 43;
	  section.data(8).dtTransOffset = 7;
	
	  ;% heli_q8_B.UnitDelay_f
	  section.data(9).logicalSrcIdx = 44;
	  section.data(9).dtTransOffset = 8;
	
	  ;% heli_q8_B.UnitDelay_m
	  section.data(10).logicalSrcIdx = 45;
	  section.data(10).dtTransOffset = 9;
	
	  ;% heli_q8_B.UnitDelay_dq
	  section.data(11).logicalSrcIdx = 46;
	  section.data(11).dtTransOffset = 10;
	
	  ;% heli_q8_B.UnitDelay_h
	  section.data(12).logicalSrcIdx = 47;
	  section.data(12).dtTransOffset = 11;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_B.StreamCall2_o2
	  section.data(1).logicalSrcIdx = 48;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(3) = section;
      clear section
      
      section.nData     = 8;
      section.data(8)  = dumData; %prealloc
      
	  ;% heli_q8_B.StreamFormattedRead1_o10
	  section.data(1).logicalSrcIdx = 49;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_B.StreamFormattedRead1_o11
	  section.data(2).logicalSrcIdx = 50;
	  section.data(2).dtTransOffset = 1;
	
	  ;% heli_q8_B.RelationalOperator
	  section.data(3).logicalSrcIdx = 51;
	  section.data(3).dtTransOffset = 2;
	
	  ;% heli_q8_B.RelationalOperator_k
	  section.data(4).logicalSrcIdx = 52;
	  section.data(4).dtTransOffset = 3;
	
	  ;% heli_q8_B.RelationalOperator_f
	  section.data(5).logicalSrcIdx = 53;
	  section.data(5).dtTransOffset = 4;
	
	  ;% heli_q8_B.RelationalOperator_o
	  section.data(6).logicalSrcIdx = 54;
	  section.data(6).dtTransOffset = 5;
	
	  ;% heli_q8_B.RelationalOperator_l
	  section.data(7).logicalSrcIdx = 55;
	  section.data(7).dtTransOffset = 6;
	
	  ;% heli_q8_B.RelationalOperator_c
	  section.data(8).logicalSrcIdx = 56;
	  section.data(8).dtTransOffset = 7;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(4) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 12;
    sectIdxOffset = 4;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (heli_q8_DW)
    ;%
      section.nData     = 13;
      section.data(13)  = dumData; %prealloc
      
	  ;% heli_q8_DW.UnitDelay_DSTATE
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_DW.UnitDelay1_DSTATE
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 6;
	
	  ;% heli_q8_DW.HILInitialize_AIMinimums
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 42;
	
	  ;% heli_q8_DW.HILInitialize_AIMaximums
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 50;
	
	  ;% heli_q8_DW.HILInitialize_AOMinimums
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 58;
	
	  ;% heli_q8_DW.HILInitialize_AOMaximums
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 66;
	
	  ;% heli_q8_DW.HILInitialize_AOVoltages
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 74;
	
	  ;% heli_q8_DW.HILInitialize_FilterFrequency
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 82;
	
	  ;% heli_q8_DW.HILInitialize_POSortedFreqs
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 90;
	
	  ;% heli_q8_DW.HILInitialize_POValues
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 98;
	
	  ;% heli_q8_DW.RateTransitionx_Buffer0
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 106;
	
	  ;% heli_q8_DW.RateTransitiony_Buffer0
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 107;
	
	  ;% heli_q8_DW.HILWriteAnalog_Buffer
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 108;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_DW.StreamCall2_Stream
	  section.data(1).logicalSrcIdx = 13;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_DW.GameController_Controller
	  section.data(1).logicalSrcIdx = 14;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_DW.HILInitialize_Card
	  section.data(1).logicalSrcIdx = 15;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_DW.HILReadEncoderTimebase_Task
	  section.data(1).logicalSrcIdx = 16;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 38;
      section.data(38)  = dumData; %prealloc
      
	  ;% heli_q8_DW.ppdotedot_PWORK.LoggedData
	  section.data(1).logicalSrcIdx = 17;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_DW.NewData_PWORK.LoggedData
	  section.data(2).logicalSrcIdx = 18;
	  section.data(2).dtTransOffset = 3;
	
	  ;% heli_q8_DW.EULERPitchelevatTravelRate1_PWO.LoggedData
	  section.data(3).logicalSrcIdx = 19;
	  section.data(3).dtTransOffset = 4;
	
	  ;% heli_q8_DW.WPitchelevatTravelRate1_PWORK.LoggedData
	  section.data(4).logicalSrcIdx = 20;
	  section.data(4).dtTransOffset = 7;
	
	  ;% heli_q8_DW.aPitchElevation1_PWORK.LoggedData
	  section.data(5).logicalSrcIdx = 21;
	  section.data(5).dtTransOffset = 10;
	
	  ;% heli_q8_DW.ToFile_PWORK.FilePtr
	  section.data(6).logicalSrcIdx = 22;
	  section.data(6).dtTransOffset = 12;
	
	  ;% heli_q8_DW.P_cov_PWORK.LoggedData
	  section.data(7).logicalSrcIdx = 23;
	  section.data(7).dtTransOffset = 13;
	
	  ;% heli_q8_DW.P_est_PWORK.LoggedData
	  section.data(8).logicalSrcIdx = 24;
	  section.data(8).dtTransOffset = 14;
	
	  ;% heli_q8_DW.ToFile1_PWORK.FilePtr
	  section.data(9).logicalSrcIdx = 25;
	  section.data(9).dtTransOffset = 15;
	
	  ;% heli_q8_DW.x_est_PWORK.LoggedData
	  section.data(10).logicalSrcIdx = 26;
	  section.data(10).dtTransOffset = 16;
	
	  ;% heli_q8_DW.x_hat_PWORK.LoggedData
	  section.data(11).logicalSrcIdx = 27;
	  section.data(11).dtTransOffset = 17;
	
	  ;% heli_q8_DW.ElevationScoperads_PWORK.LoggedData
	  section.data(12).logicalSrcIdx = 28;
	  section.data(12).dtTransOffset = 18;
	
	  ;% heli_q8_DW.ElevationScoperad_PWORK.LoggedData
	  section.data(13).logicalSrcIdx = 29;
	  section.data(13).dtTransOffset = 19;
	
	  ;% heli_q8_DW.PitchScoperad_PWORK.LoggedData
	  section.data(14).logicalSrcIdx = 30;
	  section.data(14).dtTransOffset = 20;
	
	  ;% heli_q8_DW.PtichrateScoperads_PWORK.LoggedData
	  section.data(15).logicalSrcIdx = 31;
	  section.data(15).dtTransOffset = 21;
	
	  ;% heli_q8_DW.TravelrateScoperads_PWORK.LoggedData
	  section.data(16).logicalSrcIdx = 32;
	  section.data(16).dtTransOffset = 22;
	
	  ;% heli_q8_DW.TravelScoperad_PWORK.LoggedData
	  section.data(17).logicalSrcIdx = 33;
	  section.data(17).dtTransOffset = 23;
	
	  ;% heli_q8_DW.HILWriteAnalog_PWORK
	  section.data(18).logicalSrcIdx = 34;
	  section.data(18).dtTransOffset = 24;
	
	  ;% heli_q8_DW.GYROS_PWORK.LoggedData
	  section.data(19).logicalSrcIdx = 35;
	  section.data(19).dtTransOffset = 25;
	
	  ;% heli_q8_DW.Closed_PWORK.LoggedData
	  section.data(20).logicalSrcIdx = 36;
	  section.data(20).dtTransOffset = 28;
	
	  ;% heli_q8_DW.Connected2_PWORK.LoggedData
	  section.data(21).logicalSrcIdx = 37;
	  section.data(21).dtTransOffset = 29;
	
	  ;% heli_q8_DW.Scope_PWORK.LoggedData
	  section.data(22).logicalSrcIdx = 38;
	  section.data(22).dtTransOffset = 30;
	
	  ;% heli_q8_DW.ax_PWORK.LoggedData
	  section.data(23).logicalSrcIdx = 39;
	  section.data(23).dtTransOffset = 36;
	
	  ;% heli_q8_DW.ay_PWORK.LoggedData
	  section.data(24).logicalSrcIdx = 40;
	  section.data(24).dtTransOffset = 37;
	
	  ;% heli_q8_DW.az_PWORK.LoggedData
	  section.data(25).logicalSrcIdx = 41;
	  section.data(25).dtTransOffset = 38;
	
	  ;% heli_q8_DW.wx_PWORK.LoggedData
	  section.data(26).logicalSrcIdx = 42;
	  section.data(26).dtTransOffset = 39;
	
	  ;% heli_q8_DW.wy_PWORK.LoggedData
	  section.data(27).logicalSrcIdx = 43;
	  section.data(27).dtTransOffset = 40;
	
	  ;% heli_q8_DW.wz_PWORK.LoggedData
	  section.data(28).logicalSrcIdx = 44;
	  section.data(28).dtTransOffset = 41;
	
	  ;% heli_q8_DW.Scope_PWORK_j.LoggedData
	  section.data(29).logicalSrcIdx = 45;
	  section.data(29).dtTransOffset = 42;
	
	  ;% heli_q8_DW.Scope_PWORK_a.LoggedData
	  section.data(30).logicalSrcIdx = 46;
	  section.data(30).dtTransOffset = 44;
	
	  ;% heli_q8_DW.Scope_PWORK_k.LoggedData
	  section.data(31).logicalSrcIdx = 47;
	  section.data(31).dtTransOffset = 46;
	
	  ;% heli_q8_DW.Scope_PWORK_n.LoggedData
	  section.data(32).logicalSrcIdx = 48;
	  section.data(32).dtTransOffset = 48;
	
	  ;% heli_q8_DW.Scope_PWORK_e.LoggedData
	  section.data(33).logicalSrcIdx = 49;
	  section.data(33).dtTransOffset = 50;
	
	  ;% heli_q8_DW.Scope_PWORK_jb.LoggedData
	  section.data(34).logicalSrcIdx = 50;
	  section.data(34).dtTransOffset = 52;
	
	  ;% heli_q8_DW.XScope_PWORK.LoggedData
	  section.data(35).logicalSrcIdx = 51;
	  section.data(35).dtTransOffset = 54;
	
	  ;% heli_q8_DW.YScope_PWORK.LoggedData
	  section.data(36).logicalSrcIdx = 52;
	  section.data(36).dtTransOffset = 55;
	
	  ;% heli_q8_DW.VdV_PWORK.LoggedData
	  section.data(37).logicalSrcIdx = 53;
	  section.data(37).dtTransOffset = 56;
	
	  ;% heli_q8_DW.VsV_PWORK.LoggedData
	  section.data(38).logicalSrcIdx = 54;
	  section.data(38).dtTransOffset = 57;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
      section.nData     = 6;
      section.data(6)  = dumData; %prealloc
      
	  ;% heli_q8_DW.UnitDelay_DSTATE_i
	  section.data(1).logicalSrcIdx = 55;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_DW.UnitDelay_DSTATE_o
	  section.data(2).logicalSrcIdx = 56;
	  section.data(2).dtTransOffset = 1;
	
	  ;% heli_q8_DW.UnitDelay_DSTATE_od
	  section.data(3).logicalSrcIdx = 57;
	  section.data(3).dtTransOffset = 2;
	
	  ;% heli_q8_DW.UnitDelay_DSTATE_l
	  section.data(4).logicalSrcIdx = 58;
	  section.data(4).dtTransOffset = 3;
	
	  ;% heli_q8_DW.UnitDelay_DSTATE_e
	  section.data(5).logicalSrcIdx = 59;
	  section.data(5).dtTransOffset = 4;
	
	  ;% heli_q8_DW.UnitDelay_DSTATE_ei
	  section.data(6).logicalSrcIdx = 60;
	  section.data(6).dtTransOffset = 5;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(7) = section;
      clear section
      
      section.nData     = 7;
      section.data(7)  = dumData; %prealloc
      
	  ;% heli_q8_DW.HILInitialize_ClockModes
	  section.data(1).logicalSrcIdx = 61;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_DW.HILInitialize_QuadratureModes
	  section.data(2).logicalSrcIdx = 62;
	  section.data(2).dtTransOffset = 3;
	
	  ;% heli_q8_DW.HILInitialize_InitialEICounts
	  section.data(3).logicalSrcIdx = 63;
	  section.data(3).dtTransOffset = 11;
	
	  ;% heli_q8_DW.HILInitialize_POModeValues
	  section.data(4).logicalSrcIdx = 64;
	  section.data(4).dtTransOffset = 19;
	
	  ;% heli_q8_DW.HILInitialize_POAlignValues
	  section.data(5).logicalSrcIdx = 65;
	  section.data(5).dtTransOffset = 27;
	
	  ;% heli_q8_DW.HILInitialize_POPolarityVals
	  section.data(6).logicalSrcIdx = 66;
	  section.data(6).dtTransOffset = 35;
	
	  ;% heli_q8_DW.HILReadEncoderTimebase_Buffer
	  section.data(7).logicalSrcIdx = 67;
	  section.data(7).dtTransOffset = 43;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(8) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_DW.HILInitialize_POSortedChans
	  section.data(1).logicalSrcIdx = 68;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(9) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% heli_q8_DW.ToFile_IWORK.Count
	  section.data(1).logicalSrcIdx = 69;
	  section.data(1).dtTransOffset = 0;
	
	  ;% heli_q8_DW.ToFile1_IWORK.Count
	  section.data(2).logicalSrcIdx = 70;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(10) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_DW.Skiptonextline_SubsysRanBC
	  section.data(1).logicalSrcIdx = 71;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(11) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% heli_q8_DW.StreamCall2_State
	  section.data(1).logicalSrcIdx = 72;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(12) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 1938405495;
  targMap.checksum1 = 4227729713;
  targMap.checksum2 = 881684195;
  targMap.checksum3 = 1801499755;

